﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmDatosBanco
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDatosBanco))
        Me.grpDatosEmpresa = New System.Windows.Forms.GroupBox
        Me.Label15 = New System.Windows.Forms.Label
        Me.txtSitioWeb = New System.Windows.Forms.TextBox
        Me.Label14 = New System.Windows.Forms.Label
        Me.txtTelefono = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtCasaCentral = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtRUT = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtRazonSocial = New System.Windows.Forms.TextBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtNombreFantasia = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtLimRetDiarioIslaUYU = New System.Windows.Forms.TextBox
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtLimRetDiarioIslaUSD = New System.Windows.Forms.TextBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtLimRetDiarioDependenciasUYU = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtLimRetDiarioDependenciasUSD = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.chkCCPersonas = New System.Windows.Forms.CheckBox
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.GroupBox8 = New System.Windows.Forms.GroupBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtMaximoDepCajaUYU = New System.Windows.Forms.TextBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.txtMaximoDepCajaUSD = New System.Windows.Forms.TextBox
        Me.GroupBox7 = New System.Windows.Forms.GroupBox
        Me.Label10 = New System.Windows.Forms.Label
        Me.txtMinimoDepCajaUYU = New System.Windows.Forms.TextBox
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtMinimoDepCajaUSD = New System.Windows.Forms.TextBox
        Me.btnAceptar = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.grpDatosEmpresa.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpDatosEmpresa
        '
        Me.grpDatosEmpresa.AccessibleDescription = Nothing
        Me.grpDatosEmpresa.AccessibleName = Nothing
        resources.ApplyResources(Me.grpDatosEmpresa, "grpDatosEmpresa")
        Me.grpDatosEmpresa.BackgroundImage = Nothing
        Me.grpDatosEmpresa.Controls.Add(Me.Label15)
        Me.grpDatosEmpresa.Controls.Add(Me.txtSitioWeb)
        Me.grpDatosEmpresa.Controls.Add(Me.Label14)
        Me.grpDatosEmpresa.Controls.Add(Me.txtTelefono)
        Me.grpDatosEmpresa.Controls.Add(Me.Label4)
        Me.grpDatosEmpresa.Controls.Add(Me.txtCasaCentral)
        Me.grpDatosEmpresa.Controls.Add(Me.Label3)
        Me.grpDatosEmpresa.Controls.Add(Me.txtRUT)
        Me.grpDatosEmpresa.Controls.Add(Me.Label2)
        Me.grpDatosEmpresa.Controls.Add(Me.txtRazonSocial)
        Me.grpDatosEmpresa.Controls.Add(Me.Label1)
        Me.grpDatosEmpresa.Controls.Add(Me.txtNombreFantasia)
        Me.grpDatosEmpresa.Font = Nothing
        Me.grpDatosEmpresa.Name = "grpDatosEmpresa"
        Me.grpDatosEmpresa.TabStop = False
        '
        'Label15
        '
        Me.Label15.AccessibleDescription = Nothing
        Me.Label15.AccessibleName = Nothing
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'txtSitioWeb
        '
        Me.txtSitioWeb.AccessibleDescription = Nothing
        Me.txtSitioWeb.AccessibleName = Nothing
        resources.ApplyResources(Me.txtSitioWeb, "txtSitioWeb")
        Me.txtSitioWeb.BackgroundImage = Nothing
        Me.txtSitioWeb.Font = Nothing
        Me.txtSitioWeb.Name = "txtSitioWeb"
        '
        'Label14
        '
        Me.Label14.AccessibleDescription = Nothing
        Me.Label14.AccessibleName = Nothing
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'txtTelefono
        '
        Me.txtTelefono.AccessibleDescription = Nothing
        Me.txtTelefono.AccessibleName = Nothing
        resources.ApplyResources(Me.txtTelefono, "txtTelefono")
        Me.txtTelefono.BackgroundImage = Nothing
        Me.txtTelefono.Font = Nothing
        Me.txtTelefono.Name = "txtTelefono"
        '
        'Label4
        '
        Me.Label4.AccessibleDescription = Nothing
        Me.Label4.AccessibleName = Nothing
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Name = "Label4"
        '
        'txtCasaCentral
        '
        Me.txtCasaCentral.AccessibleDescription = Nothing
        Me.txtCasaCentral.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCasaCentral, "txtCasaCentral")
        Me.txtCasaCentral.BackgroundImage = Nothing
        Me.txtCasaCentral.Font = Nothing
        Me.txtCasaCentral.Name = "txtCasaCentral"
        '
        'Label3
        '
        Me.Label3.AccessibleDescription = Nothing
        Me.Label3.AccessibleName = Nothing
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'txtRUT
        '
        Me.txtRUT.AccessibleDescription = Nothing
        Me.txtRUT.AccessibleName = Nothing
        resources.ApplyResources(Me.txtRUT, "txtRUT")
        Me.txtRUT.BackgroundImage = Nothing
        Me.txtRUT.Font = Nothing
        Me.txtRUT.Name = "txtRUT"
        '
        'Label2
        '
        Me.Label2.AccessibleDescription = Nothing
        Me.Label2.AccessibleName = Nothing
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Name = "Label2"
        '
        'txtRazonSocial
        '
        Me.txtRazonSocial.AccessibleDescription = Nothing
        Me.txtRazonSocial.AccessibleName = Nothing
        resources.ApplyResources(Me.txtRazonSocial, "txtRazonSocial")
        Me.txtRazonSocial.BackgroundImage = Nothing
        Me.txtRazonSocial.Font = Nothing
        Me.txtRazonSocial.Name = "txtRazonSocial"
        '
        'Label1
        '
        Me.Label1.AccessibleDescription = Nothing
        Me.Label1.AccessibleName = Nothing
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'txtNombreFantasia
        '
        Me.txtNombreFantasia.AccessibleDescription = Nothing
        Me.txtNombreFantasia.AccessibleName = Nothing
        resources.ApplyResources(Me.txtNombreFantasia, "txtNombreFantasia")
        Me.txtNombreFantasia.BackgroundImage = Nothing
        Me.txtNombreFantasia.Font = Nothing
        Me.txtNombreFantasia.Name = "txtNombreFantasia"
        '
        'GroupBox2
        '
        Me.GroupBox2.AccessibleDescription = Nothing
        Me.GroupBox2.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.BackgroundImage = Nothing
        Me.GroupBox2.Controls.Add(Me.GroupBox5)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Font = Nothing
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'GroupBox5
        '
        Me.GroupBox5.AccessibleDescription = Nothing
        Me.GroupBox5.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox5, "GroupBox5")
        Me.GroupBox5.BackgroundImage = Nothing
        Me.GroupBox5.Controls.Add(Me.Label6)
        Me.GroupBox5.Controls.Add(Me.txtLimRetDiarioIslaUYU)
        Me.GroupBox5.Controls.Add(Me.Label9)
        Me.GroupBox5.Controls.Add(Me.txtLimRetDiarioIslaUSD)
        Me.GroupBox5.Font = Nothing
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.TabStop = False
        '
        'Label6
        '
        Me.Label6.AccessibleDescription = Nothing
        Me.Label6.AccessibleName = Nothing
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'txtLimRetDiarioIslaUYU
        '
        Me.txtLimRetDiarioIslaUYU.AccessibleDescription = Nothing
        Me.txtLimRetDiarioIslaUYU.AccessibleName = Nothing
        resources.ApplyResources(Me.txtLimRetDiarioIslaUYU, "txtLimRetDiarioIslaUYU")
        Me.txtLimRetDiarioIslaUYU.BackgroundImage = Nothing
        Me.txtLimRetDiarioIslaUYU.Font = Nothing
        Me.txtLimRetDiarioIslaUYU.Name = "txtLimRetDiarioIslaUYU"
        '
        'Label9
        '
        Me.Label9.AccessibleDescription = Nothing
        Me.Label9.AccessibleName = Nothing
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'txtLimRetDiarioIslaUSD
        '
        Me.txtLimRetDiarioIslaUSD.AccessibleDescription = Nothing
        Me.txtLimRetDiarioIslaUSD.AccessibleName = Nothing
        resources.ApplyResources(Me.txtLimRetDiarioIslaUSD, "txtLimRetDiarioIslaUSD")
        Me.txtLimRetDiarioIslaUSD.BackgroundImage = Nothing
        Me.txtLimRetDiarioIslaUSD.Font = Nothing
        Me.txtLimRetDiarioIslaUSD.Name = "txtLimRetDiarioIslaUSD"
        '
        'GroupBox3
        '
        Me.GroupBox3.AccessibleDescription = Nothing
        Me.GroupBox3.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox3, "GroupBox3")
        Me.GroupBox3.BackgroundImage = Nothing
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.txtLimRetDiarioDependenciasUYU)
        Me.GroupBox3.Controls.Add(Me.Label7)
        Me.GroupBox3.Controls.Add(Me.txtLimRetDiarioDependenciasUSD)
        Me.GroupBox3.Font = Nothing
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.TabStop = False
        '
        'Label8
        '
        Me.Label8.AccessibleDescription = Nothing
        Me.Label8.AccessibleName = Nothing
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'txtLimRetDiarioDependenciasUYU
        '
        Me.txtLimRetDiarioDependenciasUYU.AccessibleDescription = Nothing
        Me.txtLimRetDiarioDependenciasUYU.AccessibleName = Nothing
        resources.ApplyResources(Me.txtLimRetDiarioDependenciasUYU, "txtLimRetDiarioDependenciasUYU")
        Me.txtLimRetDiarioDependenciasUYU.BackgroundImage = Nothing
        Me.txtLimRetDiarioDependenciasUYU.Font = Nothing
        Me.txtLimRetDiarioDependenciasUYU.Name = "txtLimRetDiarioDependenciasUYU"
        '
        'Label7
        '
        Me.Label7.AccessibleDescription = Nothing
        Me.Label7.AccessibleName = Nothing
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'txtLimRetDiarioDependenciasUSD
        '
        Me.txtLimRetDiarioDependenciasUSD.AccessibleDescription = Nothing
        Me.txtLimRetDiarioDependenciasUSD.AccessibleName = Nothing
        resources.ApplyResources(Me.txtLimRetDiarioDependenciasUSD, "txtLimRetDiarioDependenciasUSD")
        Me.txtLimRetDiarioDependenciasUSD.BackgroundImage = Nothing
        Me.txtLimRetDiarioDependenciasUSD.Font = Nothing
        Me.txtLimRetDiarioDependenciasUSD.Name = "txtLimRetDiarioDependenciasUSD"
        '
        'Label5
        '
        Me.Label5.AccessibleDescription = Nothing
        Me.Label5.AccessibleName = Nothing
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'chkCCPersonas
        '
        Me.chkCCPersonas.AccessibleDescription = Nothing
        Me.chkCCPersonas.AccessibleName = Nothing
        resources.ApplyResources(Me.chkCCPersonas, "chkCCPersonas")
        Me.chkCCPersonas.BackgroundImage = Nothing
        Me.chkCCPersonas.Font = Nothing
        Me.chkCCPersonas.Name = "chkCCPersonas"
        Me.chkCCPersonas.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.AccessibleDescription = Nothing
        Me.GroupBox4.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox4, "GroupBox4")
        Me.GroupBox4.BackgroundImage = Nothing
        Me.GroupBox4.Controls.Add(Me.chkCCPersonas)
        Me.GroupBox4.Font = Nothing
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.AccessibleDescription = Nothing
        Me.GroupBox6.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox6, "GroupBox6")
        Me.GroupBox6.BackgroundImage = Nothing
        Me.GroupBox6.Controls.Add(Me.GroupBox8)
        Me.GroupBox6.Controls.Add(Me.GroupBox7)
        Me.GroupBox6.Font = Nothing
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.TabStop = False
        '
        'GroupBox8
        '
        Me.GroupBox8.AccessibleDescription = Nothing
        Me.GroupBox8.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox8, "GroupBox8")
        Me.GroupBox8.BackgroundImage = Nothing
        Me.GroupBox8.Controls.Add(Me.Label12)
        Me.GroupBox8.Controls.Add(Me.txtMaximoDepCajaUYU)
        Me.GroupBox8.Controls.Add(Me.Label13)
        Me.GroupBox8.Controls.Add(Me.txtMaximoDepCajaUSD)
        Me.GroupBox8.Font = Nothing
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.TabStop = False
        '
        'Label12
        '
        Me.Label12.AccessibleDescription = Nothing
        Me.Label12.AccessibleName = Nothing
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'txtMaximoDepCajaUYU
        '
        Me.txtMaximoDepCajaUYU.AccessibleDescription = Nothing
        Me.txtMaximoDepCajaUYU.AccessibleName = Nothing
        resources.ApplyResources(Me.txtMaximoDepCajaUYU, "txtMaximoDepCajaUYU")
        Me.txtMaximoDepCajaUYU.BackgroundImage = Nothing
        Me.txtMaximoDepCajaUYU.Font = Nothing
        Me.txtMaximoDepCajaUYU.Name = "txtMaximoDepCajaUYU"
        '
        'Label13
        '
        Me.Label13.AccessibleDescription = Nothing
        Me.Label13.AccessibleName = Nothing
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'txtMaximoDepCajaUSD
        '
        Me.txtMaximoDepCajaUSD.AccessibleDescription = Nothing
        Me.txtMaximoDepCajaUSD.AccessibleName = Nothing
        resources.ApplyResources(Me.txtMaximoDepCajaUSD, "txtMaximoDepCajaUSD")
        Me.txtMaximoDepCajaUSD.BackgroundImage = Nothing
        Me.txtMaximoDepCajaUSD.Font = Nothing
        Me.txtMaximoDepCajaUSD.Name = "txtMaximoDepCajaUSD"
        '
        'GroupBox7
        '
        Me.GroupBox7.AccessibleDescription = Nothing
        Me.GroupBox7.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox7, "GroupBox7")
        Me.GroupBox7.BackgroundImage = Nothing
        Me.GroupBox7.Controls.Add(Me.Label10)
        Me.GroupBox7.Controls.Add(Me.txtMinimoDepCajaUYU)
        Me.GroupBox7.Controls.Add(Me.Label11)
        Me.GroupBox7.Controls.Add(Me.txtMinimoDepCajaUSD)
        Me.GroupBox7.Font = Nothing
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.TabStop = False
        '
        'Label10
        '
        Me.Label10.AccessibleDescription = Nothing
        Me.Label10.AccessibleName = Nothing
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'txtMinimoDepCajaUYU
        '
        Me.txtMinimoDepCajaUYU.AccessibleDescription = Nothing
        Me.txtMinimoDepCajaUYU.AccessibleName = Nothing
        resources.ApplyResources(Me.txtMinimoDepCajaUYU, "txtMinimoDepCajaUYU")
        Me.txtMinimoDepCajaUYU.BackgroundImage = Nothing
        Me.txtMinimoDepCajaUYU.Font = Nothing
        Me.txtMinimoDepCajaUYU.Name = "txtMinimoDepCajaUYU"
        '
        'Label11
        '
        Me.Label11.AccessibleDescription = Nothing
        Me.Label11.AccessibleName = Nothing
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'txtMinimoDepCajaUSD
        '
        Me.txtMinimoDepCajaUSD.AccessibleDescription = Nothing
        Me.txtMinimoDepCajaUSD.AccessibleName = Nothing
        resources.ApplyResources(Me.txtMinimoDepCajaUSD, "txtMinimoDepCajaUSD")
        Me.txtMinimoDepCajaUSD.BackgroundImage = Nothing
        Me.txtMinimoDepCajaUSD.Font = Nothing
        Me.txtMinimoDepCajaUSD.Name = "txtMinimoDepCajaUSD"
        '
        'btnAceptar
        '
        Me.btnAceptar.AccessibleDescription = Nothing
        Me.btnAceptar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnAceptar, "btnAceptar")
        Me.btnAceptar.BackgroundImage = Nothing
        Me.btnAceptar.Name = "btnAceptar"
        Me.btnAceptar.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.AccessibleDescription = Nothing
        Me.btnCancelar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnCancelar, "btnCancelar")
        Me.btnCancelar.BackgroundImage = Nothing
        Me.btnCancelar.Font = Nothing
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'frmDatosBanco
        '
        Me.AccessibleDescription = Nothing
        Me.AccessibleName = Nothing
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Nothing
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnAceptar)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.grpDatosEmpresa)
        Me.Font = Nothing
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmDatosBanco"
        Me.grpDatosEmpresa.ResumeLayout(False)
        Me.grpDatosEmpresa.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox8.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpDatosEmpresa As System.Windows.Forms.GroupBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtRazonSocial As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtNombreFantasia As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtRUT As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtCasaCentral As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtLimRetDiarioDependenciasUYU As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtLimRetDiarioIslaUYU As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtLimRetDiarioIslaUSD As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtLimRetDiarioDependenciasUSD As System.Windows.Forms.TextBox
    Friend WithEvents chkCCPersonas As System.Windows.Forms.CheckBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtMaximoDepCajaUYU As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtMaximoDepCajaUSD As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents txtMinimoDepCajaUYU As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtMinimoDepCajaUSD As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtSitioWeb As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents txtTelefono As System.Windows.Forms.TextBox
    Friend WithEvents btnAceptar As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
End Class
