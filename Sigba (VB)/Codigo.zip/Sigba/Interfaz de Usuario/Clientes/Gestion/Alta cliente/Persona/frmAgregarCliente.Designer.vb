﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAgregarClienteEmpresa
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAgregarClienteEmpresa))
        Me.grpCliente = New System.Windows.Forms.GroupBox
        Me.Label23 = New System.Windows.Forms.Label
        Me.Label22 = New System.Windows.Forms.Label
        Me.Label21 = New System.Windows.Forms.Label
        Me.lblAclaracionDoc2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtMail = New System.Windows.Forms.TextBox
        Me.txtCelular = New System.Windows.Forms.TextBox
        Me.lblCelular = New System.Windows.Forms.Label
        Me.txtTelefonoFijo = New System.Windows.Forms.TextBox
        Me.lblNomCony = New System.Windows.Forms.Label
        Me.txtNombreCony = New System.Windows.Forms.TextBox
        Me.txtCodigoPos = New System.Windows.Forms.TextBox
        Me.txtRegionRes = New System.Windows.Forms.TextBox
        Me.txtLocalidadRes = New System.Windows.Forms.TextBox
        Me.txtAclaracionDom = New System.Windows.Forms.TextBox
        Me.cboPaisRes = New System.Windows.Forms.ComboBox
        Me.txtAptoDom = New System.Windows.Forms.TextBox
        Me.txtBlockDom = New System.Windows.Forms.TextBox
        Me.txtNroDom = New System.Windows.Forms.TextBox
        Me.txtCalleDom = New System.Windows.Forms.TextBox
        Me.txtCiudadNac = New System.Windows.Forms.TextBox
        Me.cboSexo = New System.Windows.Forms.ComboBox
        Me.lblSexo = New System.Windows.Forms.Label
        Me.cboPaisNaci = New System.Windows.Forms.ComboBox
        Me.cboAnoNaci = New System.Windows.Forms.ComboBox
        Me.cboMesNaci = New System.Windows.Forms.ComboBox
        Me.cboPaisDoc = New System.Windows.Forms.ComboBox
        Me.txtNroDoc = New System.Windows.Forms.TextBox
        Me.cboTipoDoc = New System.Windows.Forms.ComboBox
        Me.lblDoc = New System.Windows.Forms.Label
        Me.cboDiaNaci = New System.Windows.Forms.ComboBox
        Me.lblNombre1 = New System.Windows.Forms.Label
        Me.txtNombre2 = New System.Windows.Forms.TextBox
        Me.txtNombre1 = New System.Windows.Forms.TextBox
        Me.lblApellido1 = New System.Windows.Forms.Label
        Me.txtApellido2 = New System.Windows.Forms.TextBox
        Me.txtApellido1 = New System.Windows.Forms.TextBox
        Me.btnNuevo = New System.Windows.Forms.Button
        Me.btnIngresar = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.Label13 = New System.Windows.Forms.Label
        Me.Label12 = New System.Windows.Forms.Label
        Me.Label11 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Label6 = New System.Windows.Forms.Label
        Me.Label7 = New System.Windows.Forms.Label
        Me.GroupBox4 = New System.Windows.Forms.GroupBox
        Me.Label1 = New System.Windows.Forms.Label
        Me.Label20 = New System.Windows.Forms.Label
        Me.Label19 = New System.Windows.Forms.Label
        Me.Label18 = New System.Windows.Forms.Label
        Me.Label17 = New System.Windows.Forms.Label
        Me.Label16 = New System.Windows.Forms.Label
        Me.Label15 = New System.Windows.Forms.Label
        Me.Label14 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.GroupBox5 = New System.Windows.Forms.GroupBox
        Me.GroupBox6 = New System.Windows.Forms.GroupBox
        Me.cboPaisDocCony = New System.Windows.Forms.ComboBox
        Me.txtNroDocCony = New System.Windows.Forms.TextBox
        Me.cboTipoDocCony = New System.Windows.Forms.ComboBox
        Me.Label24 = New System.Windows.Forms.Label
        Me.Label25 = New System.Windows.Forms.Label
        Me.Label26 = New System.Windows.Forms.Label
        Me.grpCliente.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox6.SuspendLayout()
        Me.SuspendLayout()
        '
        'grpCliente
        '
        Me.grpCliente.AccessibleDescription = Nothing
        Me.grpCliente.AccessibleName = Nothing
        resources.ApplyResources(Me.grpCliente, "grpCliente")
        Me.grpCliente.BackgroundImage = Nothing
        Me.grpCliente.Controls.Add(Me.Label23)
        Me.grpCliente.Controls.Add(Me.Label22)
        Me.grpCliente.Controls.Add(Me.Label21)
        Me.grpCliente.Controls.Add(Me.lblAclaracionDoc2)
        Me.grpCliente.Controls.Add(Me.Label3)
        Me.grpCliente.Controls.Add(Me.txtMail)
        Me.grpCliente.Controls.Add(Me.txtCelular)
        Me.grpCliente.Controls.Add(Me.lblCelular)
        Me.grpCliente.Controls.Add(Me.txtTelefonoFijo)
        Me.grpCliente.Font = Nothing
        Me.grpCliente.Name = "grpCliente"
        Me.grpCliente.TabStop = False
        '
        'Label23
        '
        Me.Label23.AccessibleDescription = Nothing
        Me.Label23.AccessibleName = Nothing
        resources.ApplyResources(Me.Label23, "Label23")
        Me.Label23.Name = "Label23"
        '
        'Label22
        '
        Me.Label22.AccessibleDescription = Nothing
        Me.Label22.AccessibleName = Nothing
        resources.ApplyResources(Me.Label22, "Label22")
        Me.Label22.Name = "Label22"
        '
        'Label21
        '
        Me.Label21.AccessibleDescription = Nothing
        Me.Label21.AccessibleName = Nothing
        resources.ApplyResources(Me.Label21, "Label21")
        Me.Label21.Name = "Label21"
        '
        'lblAclaracionDoc2
        '
        Me.lblAclaracionDoc2.AccessibleDescription = Nothing
        Me.lblAclaracionDoc2.AccessibleName = Nothing
        resources.ApplyResources(Me.lblAclaracionDoc2, "lblAclaracionDoc2")
        Me.lblAclaracionDoc2.Font = Nothing
        Me.lblAclaracionDoc2.Name = "lblAclaracionDoc2"
        '
        'Label3
        '
        Me.Label3.AccessibleDescription = Nothing
        Me.Label3.AccessibleName = Nothing
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Name = "Label3"
        '
        'txtMail
        '
        Me.txtMail.AccessibleDescription = Nothing
        Me.txtMail.AccessibleName = Nothing
        resources.ApplyResources(Me.txtMail, "txtMail")
        Me.txtMail.BackgroundImage = Nothing
        Me.txtMail.Font = Nothing
        Me.txtMail.Name = "txtMail"
        '
        'txtCelular
        '
        Me.txtCelular.AccessibleDescription = Nothing
        Me.txtCelular.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCelular, "txtCelular")
        Me.txtCelular.BackgroundImage = Nothing
        Me.txtCelular.Font = Nothing
        Me.txtCelular.Name = "txtCelular"
        '
        'lblCelular
        '
        Me.lblCelular.AccessibleDescription = Nothing
        Me.lblCelular.AccessibleName = Nothing
        resources.ApplyResources(Me.lblCelular, "lblCelular")
        Me.lblCelular.Name = "lblCelular"
        '
        'txtTelefonoFijo
        '
        Me.txtTelefonoFijo.AccessibleDescription = Nothing
        Me.txtTelefonoFijo.AccessibleName = Nothing
        resources.ApplyResources(Me.txtTelefonoFijo, "txtTelefonoFijo")
        Me.txtTelefonoFijo.BackgroundImage = Nothing
        Me.txtTelefonoFijo.Font = Nothing
        Me.txtTelefonoFijo.Name = "txtTelefonoFijo"
        '
        'lblNomCony
        '
        Me.lblNomCony.AccessibleDescription = Nothing
        Me.lblNomCony.AccessibleName = Nothing
        resources.ApplyResources(Me.lblNomCony, "lblNomCony")
        Me.lblNomCony.Name = "lblNomCony"
        '
        'txtNombreCony
        '
        Me.txtNombreCony.AccessibleDescription = Nothing
        Me.txtNombreCony.AccessibleName = Nothing
        resources.ApplyResources(Me.txtNombreCony, "txtNombreCony")
        Me.txtNombreCony.BackgroundImage = Nothing
        Me.txtNombreCony.Font = Nothing
        Me.txtNombreCony.Name = "txtNombreCony"
        '
        'txtCodigoPos
        '
        Me.txtCodigoPos.AccessibleDescription = Nothing
        Me.txtCodigoPos.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCodigoPos, "txtCodigoPos")
        Me.txtCodigoPos.BackgroundImage = Nothing
        Me.txtCodigoPos.Font = Nothing
        Me.txtCodigoPos.Name = "txtCodigoPos"
        '
        'txtRegionRes
        '
        Me.txtRegionRes.AccessibleDescription = Nothing
        Me.txtRegionRes.AccessibleName = Nothing
        resources.ApplyResources(Me.txtRegionRes, "txtRegionRes")
        Me.txtRegionRes.BackgroundImage = Nothing
        Me.txtRegionRes.Font = Nothing
        Me.txtRegionRes.Name = "txtRegionRes"
        '
        'txtLocalidadRes
        '
        Me.txtLocalidadRes.AccessibleDescription = Nothing
        Me.txtLocalidadRes.AccessibleName = Nothing
        resources.ApplyResources(Me.txtLocalidadRes, "txtLocalidadRes")
        Me.txtLocalidadRes.BackgroundImage = Nothing
        Me.txtLocalidadRes.Font = Nothing
        Me.txtLocalidadRes.Name = "txtLocalidadRes"
        '
        'txtAclaracionDom
        '
        Me.txtAclaracionDom.AccessibleDescription = Nothing
        Me.txtAclaracionDom.AccessibleName = Nothing
        resources.ApplyResources(Me.txtAclaracionDom, "txtAclaracionDom")
        Me.txtAclaracionDom.BackgroundImage = Nothing
        Me.txtAclaracionDom.Font = Nothing
        Me.txtAclaracionDom.Name = "txtAclaracionDom"
        '
        'cboPaisRes
        '
        Me.cboPaisRes.AccessibleDescription = Nothing
        Me.cboPaisRes.AccessibleName = Nothing
        resources.ApplyResources(Me.cboPaisRes, "cboPaisRes")
        Me.cboPaisRes.BackgroundImage = Nothing
        Me.cboPaisRes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPaisRes.Font = Nothing
        Me.cboPaisRes.FormattingEnabled = True
        Me.cboPaisRes.Name = "cboPaisRes"
        '
        'txtAptoDom
        '
        Me.txtAptoDom.AccessibleDescription = Nothing
        Me.txtAptoDom.AccessibleName = Nothing
        resources.ApplyResources(Me.txtAptoDom, "txtAptoDom")
        Me.txtAptoDom.BackgroundImage = Nothing
        Me.txtAptoDom.Font = Nothing
        Me.txtAptoDom.Name = "txtAptoDom"
        '
        'txtBlockDom
        '
        Me.txtBlockDom.AccessibleDescription = Nothing
        Me.txtBlockDom.AccessibleName = Nothing
        resources.ApplyResources(Me.txtBlockDom, "txtBlockDom")
        Me.txtBlockDom.BackgroundImage = Nothing
        Me.txtBlockDom.Font = Nothing
        Me.txtBlockDom.Name = "txtBlockDom"
        '
        'txtNroDom
        '
        Me.txtNroDom.AccessibleDescription = Nothing
        Me.txtNroDom.AccessibleName = Nothing
        resources.ApplyResources(Me.txtNroDom, "txtNroDom")
        Me.txtNroDom.BackgroundImage = Nothing
        Me.txtNroDom.Font = Nothing
        Me.txtNroDom.Name = "txtNroDom"
        '
        'txtCalleDom
        '
        Me.txtCalleDom.AccessibleDescription = Nothing
        Me.txtCalleDom.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCalleDom, "txtCalleDom")
        Me.txtCalleDom.BackgroundImage = Nothing
        Me.txtCalleDom.Font = Nothing
        Me.txtCalleDom.Name = "txtCalleDom"
        '
        'txtCiudadNac
        '
        Me.txtCiudadNac.AccessibleDescription = Nothing
        Me.txtCiudadNac.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCiudadNac, "txtCiudadNac")
        Me.txtCiudadNac.BackgroundImage = Nothing
        Me.txtCiudadNac.Font = Nothing
        Me.txtCiudadNac.Name = "txtCiudadNac"
        '
        'cboSexo
        '
        Me.cboSexo.AccessibleDescription = Nothing
        Me.cboSexo.AccessibleName = Nothing
        resources.ApplyResources(Me.cboSexo, "cboSexo")
        Me.cboSexo.BackgroundImage = Nothing
        Me.cboSexo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboSexo.Font = Nothing
        Me.cboSexo.FormattingEnabled = True
        Me.cboSexo.Items.AddRange(New Object() {resources.GetString("cboSexo.Items"), resources.GetString("cboSexo.Items1"), resources.GetString("cboSexo.Items2"), resources.GetString("cboSexo.Items3")})
        Me.cboSexo.Name = "cboSexo"
        '
        'lblSexo
        '
        Me.lblSexo.AccessibleDescription = Nothing
        Me.lblSexo.AccessibleName = Nothing
        resources.ApplyResources(Me.lblSexo, "lblSexo")
        Me.lblSexo.Name = "lblSexo"
        '
        'cboPaisNaci
        '
        Me.cboPaisNaci.AccessibleDescription = Nothing
        Me.cboPaisNaci.AccessibleName = Nothing
        resources.ApplyResources(Me.cboPaisNaci, "cboPaisNaci")
        Me.cboPaisNaci.BackgroundImage = Nothing
        Me.cboPaisNaci.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPaisNaci.Font = Nothing
        Me.cboPaisNaci.FormattingEnabled = True
        Me.cboPaisNaci.Name = "cboPaisNaci"
        '
        'cboAnoNaci
        '
        Me.cboAnoNaci.AccessibleDescription = Nothing
        Me.cboAnoNaci.AccessibleName = Nothing
        resources.ApplyResources(Me.cboAnoNaci, "cboAnoNaci")
        Me.cboAnoNaci.BackgroundImage = Nothing
        Me.cboAnoNaci.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboAnoNaci.Font = Nothing
        Me.cboAnoNaci.FormattingEnabled = True
        Me.cboAnoNaci.Name = "cboAnoNaci"
        '
        'cboMesNaci
        '
        Me.cboMesNaci.AccessibleDescription = Nothing
        Me.cboMesNaci.AccessibleName = Nothing
        resources.ApplyResources(Me.cboMesNaci, "cboMesNaci")
        Me.cboMesNaci.BackgroundImage = Nothing
        Me.cboMesNaci.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboMesNaci.Font = Nothing
        Me.cboMesNaci.FormattingEnabled = True
        Me.cboMesNaci.Items.AddRange(New Object() {resources.GetString("cboMesNaci.Items"), resources.GetString("cboMesNaci.Items1"), resources.GetString("cboMesNaci.Items2"), resources.GetString("cboMesNaci.Items3"), resources.GetString("cboMesNaci.Items4"), resources.GetString("cboMesNaci.Items5"), resources.GetString("cboMesNaci.Items6"), resources.GetString("cboMesNaci.Items7"), resources.GetString("cboMesNaci.Items8"), resources.GetString("cboMesNaci.Items9"), resources.GetString("cboMesNaci.Items10"), resources.GetString("cboMesNaci.Items11"), resources.GetString("cboMesNaci.Items12")})
        Me.cboMesNaci.Name = "cboMesNaci"
        '
        'cboPaisDoc
        '
        Me.cboPaisDoc.AccessibleDescription = Nothing
        Me.cboPaisDoc.AccessibleName = Nothing
        resources.ApplyResources(Me.cboPaisDoc, "cboPaisDoc")
        Me.cboPaisDoc.BackgroundImage = Nothing
        Me.cboPaisDoc.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboPaisDoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPaisDoc.Font = Nothing
        Me.cboPaisDoc.FormattingEnabled = True
        Me.cboPaisDoc.Name = "cboPaisDoc"
        '
        'txtNroDoc
        '
        Me.txtNroDoc.AccessibleDescription = Nothing
        Me.txtNroDoc.AccessibleName = Nothing
        resources.ApplyResources(Me.txtNroDoc, "txtNroDoc")
        Me.txtNroDoc.BackgroundImage = Nothing
        Me.txtNroDoc.Font = Nothing
        Me.txtNroDoc.Name = "txtNroDoc"
        '
        'cboTipoDoc
        '
        Me.cboTipoDoc.AccessibleDescription = Nothing
        Me.cboTipoDoc.AccessibleName = Nothing
        resources.ApplyResources(Me.cboTipoDoc, "cboTipoDoc")
        Me.cboTipoDoc.BackgroundImage = Nothing
        Me.cboTipoDoc.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTipoDoc.Font = Nothing
        Me.cboTipoDoc.FormattingEnabled = True
        Me.cboTipoDoc.Items.AddRange(New Object() {resources.GetString("cboTipoDoc.Items"), resources.GetString("cboTipoDoc.Items1"), resources.GetString("cboTipoDoc.Items2")})
        Me.cboTipoDoc.Name = "cboTipoDoc"
        '
        'lblDoc
        '
        Me.lblDoc.AccessibleDescription = Nothing
        Me.lblDoc.AccessibleName = Nothing
        resources.ApplyResources(Me.lblDoc, "lblDoc")
        Me.lblDoc.Name = "lblDoc"
        '
        'cboDiaNaci
        '
        Me.cboDiaNaci.AccessibleDescription = Nothing
        Me.cboDiaNaci.AccessibleName = Nothing
        resources.ApplyResources(Me.cboDiaNaci, "cboDiaNaci")
        Me.cboDiaNaci.BackgroundImage = Nothing
        Me.cboDiaNaci.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboDiaNaci.Font = Nothing
        Me.cboDiaNaci.FormattingEnabled = True
        Me.cboDiaNaci.Items.AddRange(New Object() {resources.GetString("cboDiaNaci.Items"), resources.GetString("cboDiaNaci.Items1"), resources.GetString("cboDiaNaci.Items2"), resources.GetString("cboDiaNaci.Items3"), resources.GetString("cboDiaNaci.Items4"), resources.GetString("cboDiaNaci.Items5"), resources.GetString("cboDiaNaci.Items6"), resources.GetString("cboDiaNaci.Items7"), resources.GetString("cboDiaNaci.Items8"), resources.GetString("cboDiaNaci.Items9"), resources.GetString("cboDiaNaci.Items10"), resources.GetString("cboDiaNaci.Items11"), resources.GetString("cboDiaNaci.Items12"), resources.GetString("cboDiaNaci.Items13"), resources.GetString("cboDiaNaci.Items14"), resources.GetString("cboDiaNaci.Items15"), resources.GetString("cboDiaNaci.Items16"), resources.GetString("cboDiaNaci.Items17"), resources.GetString("cboDiaNaci.Items18"), resources.GetString("cboDiaNaci.Items19"), resources.GetString("cboDiaNaci.Items20"), resources.GetString("cboDiaNaci.Items21"), resources.GetString("cboDiaNaci.Items22"), resources.GetString("cboDiaNaci.Items23"), resources.GetString("cboDiaNaci.Items24"), resources.GetString("cboDiaNaci.Items25"), resources.GetString("cboDiaNaci.Items26"), resources.GetString("cboDiaNaci.Items27"), resources.GetString("cboDiaNaci.Items28"), resources.GetString("cboDiaNaci.Items29"), resources.GetString("cboDiaNaci.Items30"), resources.GetString("cboDiaNaci.Items31")})
        Me.cboDiaNaci.Name = "cboDiaNaci"
        '
        'lblNombre1
        '
        Me.lblNombre1.AccessibleDescription = Nothing
        Me.lblNombre1.AccessibleName = Nothing
        resources.ApplyResources(Me.lblNombre1, "lblNombre1")
        Me.lblNombre1.Name = "lblNombre1"
        '
        'txtNombre2
        '
        Me.txtNombre2.AccessibleDescription = Nothing
        Me.txtNombre2.AccessibleName = Nothing
        resources.ApplyResources(Me.txtNombre2, "txtNombre2")
        Me.txtNombre2.BackgroundImage = Nothing
        Me.txtNombre2.Font = Nothing
        Me.txtNombre2.Name = "txtNombre2"
        '
        'txtNombre1
        '
        Me.txtNombre1.AccessibleDescription = Nothing
        Me.txtNombre1.AccessibleName = Nothing
        resources.ApplyResources(Me.txtNombre1, "txtNombre1")
        Me.txtNombre1.BackgroundImage = Nothing
        Me.txtNombre1.Font = Nothing
        Me.txtNombre1.Name = "txtNombre1"
        '
        'lblApellido1
        '
        Me.lblApellido1.AccessibleDescription = Nothing
        Me.lblApellido1.AccessibleName = Nothing
        resources.ApplyResources(Me.lblApellido1, "lblApellido1")
        Me.lblApellido1.Name = "lblApellido1"
        '
        'txtApellido2
        '
        Me.txtApellido2.AccessibleDescription = Nothing
        Me.txtApellido2.AccessibleName = Nothing
        resources.ApplyResources(Me.txtApellido2, "txtApellido2")
        Me.txtApellido2.BackgroundImage = Nothing
        Me.txtApellido2.Font = Nothing
        Me.txtApellido2.Name = "txtApellido2"
        '
        'txtApellido1
        '
        Me.txtApellido1.AccessibleDescription = Nothing
        Me.txtApellido1.AccessibleName = Nothing
        resources.ApplyResources(Me.txtApellido1, "txtApellido1")
        Me.txtApellido1.BackgroundImage = Nothing
        Me.txtApellido1.Font = Nothing
        Me.txtApellido1.Name = "txtApellido1"
        '
        'btnNuevo
        '
        Me.btnNuevo.AccessibleDescription = Nothing
        Me.btnNuevo.AccessibleName = Nothing
        resources.ApplyResources(Me.btnNuevo, "btnNuevo")
        Me.btnNuevo.BackgroundImage = Nothing
        Me.btnNuevo.Font = Nothing
        Me.btnNuevo.Name = "btnNuevo"
        Me.btnNuevo.UseVisualStyleBackColor = True
        '
        'btnIngresar
        '
        Me.btnIngresar.AccessibleDescription = Nothing
        Me.btnIngresar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnIngresar, "btnIngresar")
        Me.btnIngresar.BackgroundImage = Nothing
        Me.btnIngresar.Name = "btnIngresar"
        Me.btnIngresar.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.AccessibleDescription = Nothing
        Me.btnCancelar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnCancelar, "btnCancelar")
        Me.btnCancelar.BackgroundImage = Nothing
        Me.btnCancelar.Font = Nothing
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.AccessibleDescription = Nothing
        Me.GroupBox1.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox1, "GroupBox1")
        Me.GroupBox1.BackgroundImage = Nothing
        Me.GroupBox1.Controls.Add(Me.GroupBox3)
        Me.GroupBox1.Controls.Add(Me.GroupBox2)
        Me.GroupBox1.Controls.Add(Me.txtApellido1)
        Me.GroupBox1.Controls.Add(Me.lblApellido1)
        Me.GroupBox1.Controls.Add(Me.txtApellido2)
        Me.GroupBox1.Controls.Add(Me.txtNombre1)
        Me.GroupBox1.Controls.Add(Me.txtNombre2)
        Me.GroupBox1.Controls.Add(Me.lblNombre1)
        Me.GroupBox1.Controls.Add(Me.lblDoc)
        Me.GroupBox1.Controls.Add(Me.cboSexo)
        Me.GroupBox1.Controls.Add(Me.lblSexo)
        Me.GroupBox1.Font = Nothing
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.TabStop = False
        '
        'GroupBox3
        '
        Me.GroupBox3.AccessibleDescription = Nothing
        Me.GroupBox3.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox3, "GroupBox3")
        Me.GroupBox3.BackgroundImage = Nothing
        Me.GroupBox3.Controls.Add(Me.cboDiaNaci)
        Me.GroupBox3.Controls.Add(Me.cboMesNaci)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.cboAnoNaci)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.cboPaisNaci)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.txtCiudadNac)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Font = Nothing
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.TabStop = False
        '
        'Label13
        '
        Me.Label13.AccessibleDescription = Nothing
        Me.Label13.AccessibleName = Nothing
        resources.ApplyResources(Me.Label13, "Label13")
        Me.Label13.Name = "Label13"
        '
        'Label12
        '
        Me.Label12.AccessibleDescription = Nothing
        Me.Label12.AccessibleName = Nothing
        resources.ApplyResources(Me.Label12, "Label12")
        Me.Label12.Name = "Label12"
        '
        'Label11
        '
        Me.Label11.AccessibleDescription = Nothing
        Me.Label11.AccessibleName = Nothing
        resources.ApplyResources(Me.Label11, "Label11")
        Me.Label11.Name = "Label11"
        '
        'Label10
        '
        Me.Label10.AccessibleDescription = Nothing
        Me.Label10.AccessibleName = Nothing
        resources.ApplyResources(Me.Label10, "Label10")
        Me.Label10.Name = "Label10"
        '
        'Label9
        '
        Me.Label9.AccessibleDescription = Nothing
        Me.Label9.AccessibleName = Nothing
        resources.ApplyResources(Me.Label9, "Label9")
        Me.Label9.Name = "Label9"
        '
        'GroupBox2
        '
        Me.GroupBox2.AccessibleDescription = Nothing
        Me.GroupBox2.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.BackgroundImage = Nothing
        Me.GroupBox2.Controls.Add(Me.cboPaisDoc)
        Me.GroupBox2.Controls.Add(Me.txtNroDoc)
        Me.GroupBox2.Controls.Add(Me.cboTipoDoc)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Font = Nothing
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'Label5
        '
        Me.Label5.AccessibleDescription = Nothing
        Me.Label5.AccessibleName = Nothing
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Name = "Label5"
        '
        'Label6
        '
        Me.Label6.AccessibleDescription = Nothing
        Me.Label6.AccessibleName = Nothing
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Name = "Label6"
        '
        'Label7
        '
        Me.Label7.AccessibleDescription = Nothing
        Me.Label7.AccessibleName = Nothing
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Name = "Label7"
        '
        'GroupBox4
        '
        Me.GroupBox4.AccessibleDescription = Nothing
        Me.GroupBox4.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox4, "GroupBox4")
        Me.GroupBox4.BackgroundImage = Nothing
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Controls.Add(Me.Label20)
        Me.GroupBox4.Controls.Add(Me.Label19)
        Me.GroupBox4.Controls.Add(Me.Label18)
        Me.GroupBox4.Controls.Add(Me.txtCodigoPos)
        Me.GroupBox4.Controls.Add(Me.Label17)
        Me.GroupBox4.Controls.Add(Me.Label16)
        Me.GroupBox4.Controls.Add(Me.Label15)
        Me.GroupBox4.Controls.Add(Me.txtRegionRes)
        Me.GroupBox4.Controls.Add(Me.Label14)
        Me.GroupBox4.Controls.Add(Me.Label8)
        Me.GroupBox4.Controls.Add(Me.txtLocalidadRes)
        Me.GroupBox4.Controls.Add(Me.txtCalleDom)
        Me.GroupBox4.Controls.Add(Me.txtNroDom)
        Me.GroupBox4.Controls.Add(Me.txtBlockDom)
        Me.GroupBox4.Controls.Add(Me.txtAptoDom)
        Me.GroupBox4.Controls.Add(Me.cboPaisRes)
        Me.GroupBox4.Controls.Add(Me.txtAclaracionDom)
        Me.GroupBox4.Font = Nothing
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.TabStop = False
        '
        'Label1
        '
        Me.Label1.AccessibleDescription = Nothing
        Me.Label1.AccessibleName = Nothing
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Name = "Label1"
        '
        'Label20
        '
        Me.Label20.AccessibleDescription = Nothing
        Me.Label20.AccessibleName = Nothing
        resources.ApplyResources(Me.Label20, "Label20")
        Me.Label20.Name = "Label20"
        '
        'Label19
        '
        Me.Label19.AccessibleDescription = Nothing
        Me.Label19.AccessibleName = Nothing
        resources.ApplyResources(Me.Label19, "Label19")
        Me.Label19.Name = "Label19"
        '
        'Label18
        '
        Me.Label18.AccessibleDescription = Nothing
        Me.Label18.AccessibleName = Nothing
        resources.ApplyResources(Me.Label18, "Label18")
        Me.Label18.Name = "Label18"
        '
        'Label17
        '
        Me.Label17.AccessibleDescription = Nothing
        Me.Label17.AccessibleName = Nothing
        resources.ApplyResources(Me.Label17, "Label17")
        Me.Label17.Name = "Label17"
        '
        'Label16
        '
        Me.Label16.AccessibleDescription = Nothing
        Me.Label16.AccessibleName = Nothing
        resources.ApplyResources(Me.Label16, "Label16")
        Me.Label16.Name = "Label16"
        '
        'Label15
        '
        Me.Label15.AccessibleDescription = Nothing
        Me.Label15.AccessibleName = Nothing
        resources.ApplyResources(Me.Label15, "Label15")
        Me.Label15.Name = "Label15"
        '
        'Label14
        '
        Me.Label14.AccessibleDescription = Nothing
        Me.Label14.AccessibleName = Nothing
        resources.ApplyResources(Me.Label14, "Label14")
        Me.Label14.Name = "Label14"
        '
        'Label8
        '
        Me.Label8.AccessibleDescription = Nothing
        Me.Label8.AccessibleName = Nothing
        resources.ApplyResources(Me.Label8, "Label8")
        Me.Label8.Name = "Label8"
        '
        'GroupBox5
        '
        Me.GroupBox5.AccessibleDescription = Nothing
        Me.GroupBox5.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox5, "GroupBox5")
        Me.GroupBox5.BackgroundImage = Nothing
        Me.GroupBox5.Controls.Add(Me.GroupBox6)
        Me.GroupBox5.Controls.Add(Me.txtNombreCony)
        Me.GroupBox5.Controls.Add(Me.lblNomCony)
        Me.GroupBox5.Font = Nothing
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.TabStop = False
        '
        'GroupBox6
        '
        Me.GroupBox6.AccessibleDescription = Nothing
        Me.GroupBox6.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox6, "GroupBox6")
        Me.GroupBox6.BackgroundImage = Nothing
        Me.GroupBox6.Controls.Add(Me.cboPaisDocCony)
        Me.GroupBox6.Controls.Add(Me.txtNroDocCony)
        Me.GroupBox6.Controls.Add(Me.cboTipoDocCony)
        Me.GroupBox6.Controls.Add(Me.Label24)
        Me.GroupBox6.Controls.Add(Me.Label25)
        Me.GroupBox6.Controls.Add(Me.Label26)
        Me.GroupBox6.Font = Nothing
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.TabStop = False
        '
        'cboPaisDocCony
        '
        Me.cboPaisDocCony.AccessibleDescription = Nothing
        Me.cboPaisDocCony.AccessibleName = Nothing
        resources.ApplyResources(Me.cboPaisDocCony, "cboPaisDocCony")
        Me.cboPaisDocCony.BackgroundImage = Nothing
        Me.cboPaisDocCony.Cursor = System.Windows.Forms.Cursors.Default
        Me.cboPaisDocCony.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPaisDocCony.Font = Nothing
        Me.cboPaisDocCony.FormattingEnabled = True
        Me.cboPaisDocCony.Name = "cboPaisDocCony"
        '
        'txtNroDocCony
        '
        Me.txtNroDocCony.AccessibleDescription = Nothing
        Me.txtNroDocCony.AccessibleName = Nothing
        resources.ApplyResources(Me.txtNroDocCony, "txtNroDocCony")
        Me.txtNroDocCony.BackgroundImage = Nothing
        Me.txtNroDocCony.Font = Nothing
        Me.txtNroDocCony.Name = "txtNroDocCony"
        '
        'cboTipoDocCony
        '
        Me.cboTipoDocCony.AccessibleDescription = Nothing
        Me.cboTipoDocCony.AccessibleName = Nothing
        resources.ApplyResources(Me.cboTipoDocCony, "cboTipoDocCony")
        Me.cboTipoDocCony.BackgroundImage = Nothing
        Me.cboTipoDocCony.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTipoDocCony.Font = Nothing
        Me.cboTipoDocCony.FormattingEnabled = True
        Me.cboTipoDocCony.Items.AddRange(New Object() {resources.GetString("cboTipoDocCony.Items"), resources.GetString("cboTipoDocCony.Items1"), resources.GetString("cboTipoDocCony.Items2")})
        Me.cboTipoDocCony.Name = "cboTipoDocCony"
        '
        'Label24
        '
        Me.Label24.AccessibleDescription = Nothing
        Me.Label24.AccessibleName = Nothing
        resources.ApplyResources(Me.Label24, "Label24")
        Me.Label24.Name = "Label24"
        '
        'Label25
        '
        Me.Label25.AccessibleDescription = Nothing
        Me.Label25.AccessibleName = Nothing
        resources.ApplyResources(Me.Label25, "Label25")
        Me.Label25.Name = "Label25"
        '
        'Label26
        '
        Me.Label26.AccessibleDescription = Nothing
        Me.Label26.AccessibleName = Nothing
        resources.ApplyResources(Me.Label26, "Label26")
        Me.Label26.Name = "Label26"
        '
        'frmAgregarClienteEmpresa
        '
        Me.AccessibleDescription = Nothing
        Me.AccessibleName = Nothing
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Nothing
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnNuevo)
        Me.Controls.Add(Me.grpCliente)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnIngresar)
        Me.Font = Nothing
        Me.MaximizeBox = False
        Me.Name = "frmAgregarClienteEmpresa"
        Me.grpCliente.ResumeLayout(False)
        Me.grpCliente.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox5.PerformLayout()
        Me.GroupBox6.ResumeLayout(False)
        Me.GroupBox6.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents grpCliente As System.Windows.Forms.GroupBox
    Friend WithEvents lblApellido1 As System.Windows.Forms.Label
    Friend WithEvents txtApellido2 As System.Windows.Forms.TextBox
    Friend WithEvents txtApellido1 As System.Windows.Forms.TextBox
    Friend WithEvents lblNombre1 As System.Windows.Forms.Label
    Friend WithEvents txtNombre2 As System.Windows.Forms.TextBox
    Friend WithEvents txtNombre1 As System.Windows.Forms.TextBox
    Friend WithEvents cboDiaNaci As System.Windows.Forms.ComboBox
    Friend WithEvents cboTipoDoc As System.Windows.Forms.ComboBox
    Friend WithEvents lblDoc As System.Windows.Forms.Label
    Friend WithEvents cboPaisDoc As System.Windows.Forms.ComboBox
    Friend WithEvents txtNroDoc As System.Windows.Forms.TextBox
    Friend WithEvents cboAnoNaci As System.Windows.Forms.ComboBox
    Friend WithEvents cboMesNaci As System.Windows.Forms.ComboBox
    Friend WithEvents txtNroDom As System.Windows.Forms.TextBox
    Friend WithEvents txtCalleDom As System.Windows.Forms.TextBox
    Friend WithEvents txtAptoDom As System.Windows.Forms.TextBox
    Friend WithEvents txtBlockDom As System.Windows.Forms.TextBox
    Friend WithEvents cboPaisRes As System.Windows.Forms.ComboBox
    Friend WithEvents txtAclaracionDom As System.Windows.Forms.TextBox
    Friend WithEvents txtTelefonoFijo As System.Windows.Forms.TextBox
    Friend WithEvents txtCelular As System.Windows.Forms.TextBox
    Friend WithEvents lblCelular As System.Windows.Forms.Label
    Friend WithEvents txtMail As System.Windows.Forms.TextBox
    Friend WithEvents txtNombreCony As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblNomCony As System.Windows.Forms.Label
    Friend WithEvents btnNuevo As System.Windows.Forms.Button
    Friend WithEvents btnIngresar As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents cboPaisNaci As System.Windows.Forms.ComboBox
    Friend WithEvents lblAclaracionDoc2 As System.Windows.Forms.Label
    Friend WithEvents cboSexo As System.Windows.Forms.ComboBox
    Friend WithEvents lblSexo As System.Windows.Forms.Label
    Friend WithEvents txtLocalidadRes As System.Windows.Forms.TextBox
    Friend WithEvents txtCiudadNac As System.Windows.Forms.TextBox
    Friend WithEvents txtRegionRes As System.Windows.Forms.TextBox
    Friend WithEvents txtCodigoPos As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox6 As System.Windows.Forms.GroupBox
    Friend WithEvents cboPaisDocCony As System.Windows.Forms.ComboBox
    Friend WithEvents txtNroDocCony As System.Windows.Forms.TextBox
    Friend WithEvents cboTipoDocCony As System.Windows.Forms.ComboBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
End Class
