﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAltaClienteEmpresa
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAltaClienteEmpresa))
        Me.TextBox41 = New System.Windows.Forms.TextBox
        Me.ComboBox20 = New System.Windows.Forms.ComboBox
        Me.TextBox42 = New System.Windows.Forms.TextBox
        Me.ComboBox21 = New System.Windows.Forms.ComboBox
        Me.TextBox43 = New System.Windows.Forms.TextBox
        Me.ComboBox22 = New System.Windows.Forms.ComboBox
        Me.TextBox44 = New System.Windows.Forms.TextBox
        Me.ComboBox23 = New System.Windows.Forms.ComboBox
        Me.TextBox45 = New System.Windows.Forms.TextBox
        Me.ComboBox24 = New System.Windows.Forms.ComboBox
        Me.TextBox46 = New System.Windows.Forms.TextBox
        Me.ComboBox25 = New System.Windows.Forms.ComboBox
        Me.TextBox47 = New System.Windows.Forms.TextBox
        Me.TextBox48 = New System.Windows.Forms.TextBox
        Me.TextBox49 = New System.Windows.Forms.TextBox
        Me.TextBox50 = New System.Windows.Forms.TextBox
        Me.ComboBox26 = New System.Windows.Forms.ComboBox
        Me.TextBox51 = New System.Windows.Forms.TextBox
        Me.ComboBox27 = New System.Windows.Forms.ComboBox
        Me.TextBox52 = New System.Windows.Forms.TextBox
        Me.ComboBox28 = New System.Windows.Forms.ComboBox
        Me.TextBox53 = New System.Windows.Forms.TextBox
        Me.ComboBox29 = New System.Windows.Forms.ComboBox
        Me.TextBox54 = New System.Windows.Forms.TextBox
        Me.ComboBox30 = New System.Windows.Forms.ComboBox
        Me.TextBox55 = New System.Windows.Forms.TextBox
        Me.ComboBox31 = New System.Windows.Forms.ComboBox
        Me.TextBox56 = New System.Windows.Forms.TextBox
        Me.ComboBox32 = New System.Windows.Forms.ComboBox
        Me.TextBox57 = New System.Windows.Forms.TextBox
        Me.ComboBox33 = New System.Windows.Forms.ComboBox
        Me.Label28 = New System.Windows.Forms.Label
        Me.Label29 = New System.Windows.Forms.Label
        Me.TextBox58 = New System.Windows.Forms.TextBox
        Me.ComboBox34 = New System.Windows.Forms.ComboBox
        Me.TextBox59 = New System.Windows.Forms.TextBox
        Me.TextBox60 = New System.Windows.Forms.TextBox
        Me.ComboBox35 = New System.Windows.Forms.ComboBox
        Me.TextBox61 = New System.Windows.Forms.TextBox
        Me.TextBox62 = New System.Windows.Forms.TextBox
        Me.TextBox63 = New System.Windows.Forms.TextBox
        Me.TextBox64 = New System.Windows.Forms.TextBox
        Me.Label30 = New System.Windows.Forms.Label
        Me.RadioButton3 = New System.Windows.Forms.RadioButton
        Me.RadioButton4 = New System.Windows.Forms.RadioButton
        Me.Label31 = New System.Windows.Forms.Label
        Me.btnEnviar = New System.Windows.Forms.Button
        Me.btnLimpiar = New System.Windows.Forms.Button
        Me.grpDatosEmpresa = New System.Windows.Forms.GroupBox
        Me.grpContacto = New System.Windows.Forms.GroupBox
        Me.lblWeb = New System.Windows.Forms.Label
        Me.txtContactoSitioWeb = New System.Windows.Forms.TextBox
        Me.lblEmail = New System.Windows.Forms.Label
        Me.txtContactoEmail = New System.Windows.Forms.TextBox
        Me.lblTelefonos = New System.Windows.Forms.Label
        Me.txtContactoNumerosTelefono = New System.Windows.Forms.TextBox
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.lblCodPostal = New System.Windows.Forms.Label
        Me.txtDomicilioEmpresaCodPostal = New System.Windows.Forms.TextBox
        Me.lblAPTDomicilio = New System.Windows.Forms.Label
        Me.txtDomicilioEmpresaApartamento = New System.Windows.Forms.TextBox
        Me.lblBlockDomicilio = New System.Windows.Forms.Label
        Me.txtDomicilioEmpresaBlock = New System.Windows.Forms.TextBox
        Me.lblNroDomicilio = New System.Windows.Forms.Label
        Me.txtDomicilioEmpresaNumero = New System.Windows.Forms.TextBox
        Me.lblCalleDomicilio = New System.Windows.Forms.Label
        Me.txtDomicilioEmpresaCalle = New System.Windows.Forms.TextBox
        Me.lblDepartamento = New System.Windows.Forms.Label
        Me.txtDepartamentoEmpresa = New System.Windows.Forms.TextBox
        Me.lblCiudad = New System.Windows.Forms.Label
        Me.txtCiudadEmpresa = New System.Windows.Forms.TextBox
        Me.cboPaisResidenciaEmpresa = New System.Windows.Forms.ComboBox
        Me.lblPaisResidencia = New System.Windows.Forms.Label
        Me.cboPaisOrigenCapital = New System.Windows.Forms.ComboBox
        Me.txtRUT = New System.Windows.Forms.TextBox
        Me.lblPaisOrigen = New System.Windows.Forms.Label
        Me.cboTipoSociedad = New System.Windows.Forms.ComboBox
        Me.lblRUT = New System.Windows.Forms.Label
        Me.lblTipoSociedad = New System.Windows.Forms.Label
        Me.lblRazonSocial = New System.Windows.Forms.Label
        Me.txtRazonSocial = New System.Windows.Forms.TextBox
        Me.grpDatosEmpresa.SuspendLayout()
        Me.grpContacto.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox41
        '
        Me.TextBox41.AccessibleDescription = Nothing
        Me.TextBox41.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox41, "TextBox41")
        Me.TextBox41.BackgroundImage = Nothing
        Me.TextBox41.Font = Nothing
        Me.TextBox41.Name = "TextBox41"
        '
        'ComboBox20
        '
        Me.ComboBox20.AccessibleDescription = Nothing
        Me.ComboBox20.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox20, "ComboBox20")
        Me.ComboBox20.BackgroundImage = Nothing
        Me.ComboBox20.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox20.Font = Nothing
        Me.ComboBox20.FormattingEnabled = True
        Me.ComboBox20.Items.AddRange(New Object() {resources.GetString("ComboBox20.Items"), resources.GetString("ComboBox20.Items1"), resources.GetString("ComboBox20.Items2"), resources.GetString("ComboBox20.Items3"), resources.GetString("ComboBox20.Items4"), resources.GetString("ComboBox20.Items5"), resources.GetString("ComboBox20.Items6"), resources.GetString("ComboBox20.Items7"), resources.GetString("ComboBox20.Items8"), resources.GetString("ComboBox20.Items9"), resources.GetString("ComboBox20.Items10"), resources.GetString("ComboBox20.Items11"), resources.GetString("ComboBox20.Items12"), resources.GetString("ComboBox20.Items13"), resources.GetString("ComboBox20.Items14"), resources.GetString("ComboBox20.Items15"), resources.GetString("ComboBox20.Items16"), resources.GetString("ComboBox20.Items17"), resources.GetString("ComboBox20.Items18"), resources.GetString("ComboBox20.Items19"), resources.GetString("ComboBox20.Items20"), resources.GetString("ComboBox20.Items21"), resources.GetString("ComboBox20.Items22"), resources.GetString("ComboBox20.Items23"), resources.GetString("ComboBox20.Items24"), resources.GetString("ComboBox20.Items25"), resources.GetString("ComboBox20.Items26"), resources.GetString("ComboBox20.Items27"), resources.GetString("ComboBox20.Items28"), resources.GetString("ComboBox20.Items29"), resources.GetString("ComboBox20.Items30"), resources.GetString("ComboBox20.Items31"), resources.GetString("ComboBox20.Items32"), resources.GetString("ComboBox20.Items33"), resources.GetString("ComboBox20.Items34"), resources.GetString("ComboBox20.Items35"), resources.GetString("ComboBox20.Items36"), resources.GetString("ComboBox20.Items37"), resources.GetString("ComboBox20.Items38"), resources.GetString("ComboBox20.Items39"), resources.GetString("ComboBox20.Items40"), resources.GetString("ComboBox20.Items41"), resources.GetString("ComboBox20.Items42"), resources.GetString("ComboBox20.Items43"), resources.GetString("ComboBox20.Items44"), resources.GetString("ComboBox20.Items45"), resources.GetString("ComboBox20.Items46"), resources.GetString("ComboBox20.Items47"), resources.GetString("ComboBox20.Items48"), resources.GetString("ComboBox20.Items49"), resources.GetString("ComboBox20.Items50"), resources.GetString("ComboBox20.Items51"), resources.GetString("ComboBox20.Items52"), resources.GetString("ComboBox20.Items53"), resources.GetString("ComboBox20.Items54"), resources.GetString("ComboBox20.Items55"), resources.GetString("ComboBox20.Items56"), resources.GetString("ComboBox20.Items57"), resources.GetString("ComboBox20.Items58"), resources.GetString("ComboBox20.Items59"), resources.GetString("ComboBox20.Items60"), resources.GetString("ComboBox20.Items61"), resources.GetString("ComboBox20.Items62"), resources.GetString("ComboBox20.Items63"), resources.GetString("ComboBox20.Items64"), resources.GetString("ComboBox20.Items65"), resources.GetString("ComboBox20.Items66"), resources.GetString("ComboBox20.Items67"), resources.GetString("ComboBox20.Items68"), resources.GetString("ComboBox20.Items69"), resources.GetString("ComboBox20.Items70"), resources.GetString("ComboBox20.Items71"), resources.GetString("ComboBox20.Items72"), resources.GetString("ComboBox20.Items73"), resources.GetString("ComboBox20.Items74"), resources.GetString("ComboBox20.Items75"), resources.GetString("ComboBox20.Items76"), resources.GetString("ComboBox20.Items77"), resources.GetString("ComboBox20.Items78"), resources.GetString("ComboBox20.Items79"), resources.GetString("ComboBox20.Items80"), resources.GetString("ComboBox20.Items81"), resources.GetString("ComboBox20.Items82"), resources.GetString("ComboBox20.Items83"), resources.GetString("ComboBox20.Items84"), resources.GetString("ComboBox20.Items85"), resources.GetString("ComboBox20.Items86"), resources.GetString("ComboBox20.Items87"), resources.GetString("ComboBox20.Items88"), resources.GetString("ComboBox20.Items89"), resources.GetString("ComboBox20.Items90"), resources.GetString("ComboBox20.Items91"), resources.GetString("ComboBox20.Items92"), resources.GetString("ComboBox20.Items93"), resources.GetString("ComboBox20.Items94"), resources.GetString("ComboBox20.Items95"), resources.GetString("ComboBox20.Items96"), resources.GetString("ComboBox20.Items97"), resources.GetString("ComboBox20.Items98"), resources.GetString("ComboBox20.Items99"), resources.GetString("ComboBox20.Items100"), resources.GetString("ComboBox20.Items101"), resources.GetString("ComboBox20.Items102"), resources.GetString("ComboBox20.Items103"), resources.GetString("ComboBox20.Items104"), resources.GetString("ComboBox20.Items105"), resources.GetString("ComboBox20.Items106"), resources.GetString("ComboBox20.Items107"), resources.GetString("ComboBox20.Items108"), resources.GetString("ComboBox20.Items109"), resources.GetString("ComboBox20.Items110"), resources.GetString("ComboBox20.Items111"), resources.GetString("ComboBox20.Items112"), resources.GetString("ComboBox20.Items113"), resources.GetString("ComboBox20.Items114"), resources.GetString("ComboBox20.Items115"), resources.GetString("ComboBox20.Items116"), resources.GetString("ComboBox20.Items117"), resources.GetString("ComboBox20.Items118"), resources.GetString("ComboBox20.Items119"), resources.GetString("ComboBox20.Items120"), resources.GetString("ComboBox20.Items121"), resources.GetString("ComboBox20.Items122"), resources.GetString("ComboBox20.Items123"), resources.GetString("ComboBox20.Items124"), resources.GetString("ComboBox20.Items125"), resources.GetString("ComboBox20.Items126"), resources.GetString("ComboBox20.Items127"), resources.GetString("ComboBox20.Items128"), resources.GetString("ComboBox20.Items129"), resources.GetString("ComboBox20.Items130"), resources.GetString("ComboBox20.Items131"), resources.GetString("ComboBox20.Items132"), resources.GetString("ComboBox20.Items133"), resources.GetString("ComboBox20.Items134"), resources.GetString("ComboBox20.Items135"), resources.GetString("ComboBox20.Items136"), resources.GetString("ComboBox20.Items137"), resources.GetString("ComboBox20.Items138"), resources.GetString("ComboBox20.Items139"), resources.GetString("ComboBox20.Items140"), resources.GetString("ComboBox20.Items141"), resources.GetString("ComboBox20.Items142"), resources.GetString("ComboBox20.Items143"), resources.GetString("ComboBox20.Items144"), resources.GetString("ComboBox20.Items145"), resources.GetString("ComboBox20.Items146"), resources.GetString("ComboBox20.Items147"), resources.GetString("ComboBox20.Items148"), resources.GetString("ComboBox20.Items149"), resources.GetString("ComboBox20.Items150"), resources.GetString("ComboBox20.Items151"), resources.GetString("ComboBox20.Items152"), resources.GetString("ComboBox20.Items153"), resources.GetString("ComboBox20.Items154"), resources.GetString("ComboBox20.Items155"), resources.GetString("ComboBox20.Items156"), resources.GetString("ComboBox20.Items157"), resources.GetString("ComboBox20.Items158"), resources.GetString("ComboBox20.Items159"), resources.GetString("ComboBox20.Items160"), resources.GetString("ComboBox20.Items161"), resources.GetString("ComboBox20.Items162"), resources.GetString("ComboBox20.Items163"), resources.GetString("ComboBox20.Items164"), resources.GetString("ComboBox20.Items165"), resources.GetString("ComboBox20.Items166"), resources.GetString("ComboBox20.Items167"), resources.GetString("ComboBox20.Items168"), resources.GetString("ComboBox20.Items169"), resources.GetString("ComboBox20.Items170"), resources.GetString("ComboBox20.Items171"), resources.GetString("ComboBox20.Items172"), resources.GetString("ComboBox20.Items173"), resources.GetString("ComboBox20.Items174"), resources.GetString("ComboBox20.Items175"), resources.GetString("ComboBox20.Items176"), resources.GetString("ComboBox20.Items177"), resources.GetString("ComboBox20.Items178"), resources.GetString("ComboBox20.Items179"), resources.GetString("ComboBox20.Items180"), resources.GetString("ComboBox20.Items181"), resources.GetString("ComboBox20.Items182"), resources.GetString("ComboBox20.Items183"), resources.GetString("ComboBox20.Items184"), resources.GetString("ComboBox20.Items185"), resources.GetString("ComboBox20.Items186"), resources.GetString("ComboBox20.Items187"), resources.GetString("ComboBox20.Items188"), resources.GetString("ComboBox20.Items189"), resources.GetString("ComboBox20.Items190"), resources.GetString("ComboBox20.Items191"), resources.GetString("ComboBox20.Items192"), resources.GetString("ComboBox20.Items193"), resources.GetString("ComboBox20.Items194"), resources.GetString("ComboBox20.Items195"), resources.GetString("ComboBox20.Items196")})
        Me.ComboBox20.Name = "ComboBox20"
        '
        'TextBox42
        '
        Me.TextBox42.AccessibleDescription = Nothing
        Me.TextBox42.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox42, "TextBox42")
        Me.TextBox42.BackgroundImage = Nothing
        Me.TextBox42.Font = Nothing
        Me.TextBox42.Name = "TextBox42"
        '
        'ComboBox21
        '
        Me.ComboBox21.AccessibleDescription = Nothing
        Me.ComboBox21.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox21, "ComboBox21")
        Me.ComboBox21.BackgroundImage = Nothing
        Me.ComboBox21.Font = Nothing
        Me.ComboBox21.FormattingEnabled = True
        Me.ComboBox21.Items.AddRange(New Object() {resources.GetString("ComboBox21.Items"), resources.GetString("ComboBox21.Items1"), resources.GetString("ComboBox21.Items2")})
        Me.ComboBox21.Name = "ComboBox21"
        '
        'TextBox43
        '
        Me.TextBox43.AccessibleDescription = Nothing
        Me.TextBox43.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox43, "TextBox43")
        Me.TextBox43.BackgroundImage = Nothing
        Me.TextBox43.Font = Nothing
        Me.TextBox43.Name = "TextBox43"
        '
        'ComboBox22
        '
        Me.ComboBox22.AccessibleDescription = Nothing
        Me.ComboBox22.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox22, "ComboBox22")
        Me.ComboBox22.BackgroundImage = Nothing
        Me.ComboBox22.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox22.Font = Nothing
        Me.ComboBox22.FormattingEnabled = True
        Me.ComboBox22.Items.AddRange(New Object() {resources.GetString("ComboBox22.Items"), resources.GetString("ComboBox22.Items1"), resources.GetString("ComboBox22.Items2"), resources.GetString("ComboBox22.Items3"), resources.GetString("ComboBox22.Items4"), resources.GetString("ComboBox22.Items5"), resources.GetString("ComboBox22.Items6"), resources.GetString("ComboBox22.Items7"), resources.GetString("ComboBox22.Items8"), resources.GetString("ComboBox22.Items9"), resources.GetString("ComboBox22.Items10"), resources.GetString("ComboBox22.Items11"), resources.GetString("ComboBox22.Items12"), resources.GetString("ComboBox22.Items13"), resources.GetString("ComboBox22.Items14"), resources.GetString("ComboBox22.Items15"), resources.GetString("ComboBox22.Items16"), resources.GetString("ComboBox22.Items17"), resources.GetString("ComboBox22.Items18"), resources.GetString("ComboBox22.Items19"), resources.GetString("ComboBox22.Items20"), resources.GetString("ComboBox22.Items21"), resources.GetString("ComboBox22.Items22"), resources.GetString("ComboBox22.Items23"), resources.GetString("ComboBox22.Items24"), resources.GetString("ComboBox22.Items25"), resources.GetString("ComboBox22.Items26"), resources.GetString("ComboBox22.Items27"), resources.GetString("ComboBox22.Items28"), resources.GetString("ComboBox22.Items29"), resources.GetString("ComboBox22.Items30"), resources.GetString("ComboBox22.Items31"), resources.GetString("ComboBox22.Items32"), resources.GetString("ComboBox22.Items33"), resources.GetString("ComboBox22.Items34"), resources.GetString("ComboBox22.Items35"), resources.GetString("ComboBox22.Items36"), resources.GetString("ComboBox22.Items37"), resources.GetString("ComboBox22.Items38"), resources.GetString("ComboBox22.Items39"), resources.GetString("ComboBox22.Items40"), resources.GetString("ComboBox22.Items41"), resources.GetString("ComboBox22.Items42"), resources.GetString("ComboBox22.Items43"), resources.GetString("ComboBox22.Items44"), resources.GetString("ComboBox22.Items45"), resources.GetString("ComboBox22.Items46"), resources.GetString("ComboBox22.Items47"), resources.GetString("ComboBox22.Items48"), resources.GetString("ComboBox22.Items49"), resources.GetString("ComboBox22.Items50"), resources.GetString("ComboBox22.Items51"), resources.GetString("ComboBox22.Items52"), resources.GetString("ComboBox22.Items53"), resources.GetString("ComboBox22.Items54"), resources.GetString("ComboBox22.Items55"), resources.GetString("ComboBox22.Items56"), resources.GetString("ComboBox22.Items57"), resources.GetString("ComboBox22.Items58"), resources.GetString("ComboBox22.Items59"), resources.GetString("ComboBox22.Items60"), resources.GetString("ComboBox22.Items61"), resources.GetString("ComboBox22.Items62"), resources.GetString("ComboBox22.Items63"), resources.GetString("ComboBox22.Items64"), resources.GetString("ComboBox22.Items65"), resources.GetString("ComboBox22.Items66"), resources.GetString("ComboBox22.Items67"), resources.GetString("ComboBox22.Items68"), resources.GetString("ComboBox22.Items69"), resources.GetString("ComboBox22.Items70"), resources.GetString("ComboBox22.Items71"), resources.GetString("ComboBox22.Items72"), resources.GetString("ComboBox22.Items73"), resources.GetString("ComboBox22.Items74"), resources.GetString("ComboBox22.Items75"), resources.GetString("ComboBox22.Items76"), resources.GetString("ComboBox22.Items77"), resources.GetString("ComboBox22.Items78"), resources.GetString("ComboBox22.Items79"), resources.GetString("ComboBox22.Items80"), resources.GetString("ComboBox22.Items81"), resources.GetString("ComboBox22.Items82"), resources.GetString("ComboBox22.Items83"), resources.GetString("ComboBox22.Items84"), resources.GetString("ComboBox22.Items85"), resources.GetString("ComboBox22.Items86"), resources.GetString("ComboBox22.Items87"), resources.GetString("ComboBox22.Items88"), resources.GetString("ComboBox22.Items89"), resources.GetString("ComboBox22.Items90"), resources.GetString("ComboBox22.Items91"), resources.GetString("ComboBox22.Items92"), resources.GetString("ComboBox22.Items93"), resources.GetString("ComboBox22.Items94"), resources.GetString("ComboBox22.Items95"), resources.GetString("ComboBox22.Items96"), resources.GetString("ComboBox22.Items97"), resources.GetString("ComboBox22.Items98"), resources.GetString("ComboBox22.Items99"), resources.GetString("ComboBox22.Items100"), resources.GetString("ComboBox22.Items101"), resources.GetString("ComboBox22.Items102"), resources.GetString("ComboBox22.Items103"), resources.GetString("ComboBox22.Items104"), resources.GetString("ComboBox22.Items105"), resources.GetString("ComboBox22.Items106"), resources.GetString("ComboBox22.Items107"), resources.GetString("ComboBox22.Items108"), resources.GetString("ComboBox22.Items109"), resources.GetString("ComboBox22.Items110"), resources.GetString("ComboBox22.Items111"), resources.GetString("ComboBox22.Items112"), resources.GetString("ComboBox22.Items113"), resources.GetString("ComboBox22.Items114"), resources.GetString("ComboBox22.Items115"), resources.GetString("ComboBox22.Items116"), resources.GetString("ComboBox22.Items117"), resources.GetString("ComboBox22.Items118"), resources.GetString("ComboBox22.Items119"), resources.GetString("ComboBox22.Items120"), resources.GetString("ComboBox22.Items121"), resources.GetString("ComboBox22.Items122"), resources.GetString("ComboBox22.Items123"), resources.GetString("ComboBox22.Items124"), resources.GetString("ComboBox22.Items125"), resources.GetString("ComboBox22.Items126"), resources.GetString("ComboBox22.Items127"), resources.GetString("ComboBox22.Items128"), resources.GetString("ComboBox22.Items129"), resources.GetString("ComboBox22.Items130"), resources.GetString("ComboBox22.Items131"), resources.GetString("ComboBox22.Items132"), resources.GetString("ComboBox22.Items133"), resources.GetString("ComboBox22.Items134"), resources.GetString("ComboBox22.Items135"), resources.GetString("ComboBox22.Items136"), resources.GetString("ComboBox22.Items137"), resources.GetString("ComboBox22.Items138"), resources.GetString("ComboBox22.Items139"), resources.GetString("ComboBox22.Items140"), resources.GetString("ComboBox22.Items141"), resources.GetString("ComboBox22.Items142"), resources.GetString("ComboBox22.Items143"), resources.GetString("ComboBox22.Items144"), resources.GetString("ComboBox22.Items145"), resources.GetString("ComboBox22.Items146"), resources.GetString("ComboBox22.Items147"), resources.GetString("ComboBox22.Items148"), resources.GetString("ComboBox22.Items149"), resources.GetString("ComboBox22.Items150"), resources.GetString("ComboBox22.Items151"), resources.GetString("ComboBox22.Items152"), resources.GetString("ComboBox22.Items153"), resources.GetString("ComboBox22.Items154"), resources.GetString("ComboBox22.Items155"), resources.GetString("ComboBox22.Items156"), resources.GetString("ComboBox22.Items157"), resources.GetString("ComboBox22.Items158"), resources.GetString("ComboBox22.Items159"), resources.GetString("ComboBox22.Items160"), resources.GetString("ComboBox22.Items161"), resources.GetString("ComboBox22.Items162"), resources.GetString("ComboBox22.Items163"), resources.GetString("ComboBox22.Items164"), resources.GetString("ComboBox22.Items165"), resources.GetString("ComboBox22.Items166"), resources.GetString("ComboBox22.Items167"), resources.GetString("ComboBox22.Items168"), resources.GetString("ComboBox22.Items169"), resources.GetString("ComboBox22.Items170"), resources.GetString("ComboBox22.Items171"), resources.GetString("ComboBox22.Items172"), resources.GetString("ComboBox22.Items173"), resources.GetString("ComboBox22.Items174"), resources.GetString("ComboBox22.Items175"), resources.GetString("ComboBox22.Items176"), resources.GetString("ComboBox22.Items177"), resources.GetString("ComboBox22.Items178"), resources.GetString("ComboBox22.Items179"), resources.GetString("ComboBox22.Items180"), resources.GetString("ComboBox22.Items181"), resources.GetString("ComboBox22.Items182"), resources.GetString("ComboBox22.Items183"), resources.GetString("ComboBox22.Items184"), resources.GetString("ComboBox22.Items185"), resources.GetString("ComboBox22.Items186"), resources.GetString("ComboBox22.Items187"), resources.GetString("ComboBox22.Items188"), resources.GetString("ComboBox22.Items189"), resources.GetString("ComboBox22.Items190"), resources.GetString("ComboBox22.Items191"), resources.GetString("ComboBox22.Items192"), resources.GetString("ComboBox22.Items193"), resources.GetString("ComboBox22.Items194"), resources.GetString("ComboBox22.Items195"), resources.GetString("ComboBox22.Items196")})
        Me.ComboBox22.Name = "ComboBox22"
        '
        'TextBox44
        '
        Me.TextBox44.AccessibleDescription = Nothing
        Me.TextBox44.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox44, "TextBox44")
        Me.TextBox44.BackgroundImage = Nothing
        Me.TextBox44.Font = Nothing
        Me.TextBox44.Name = "TextBox44"
        '
        'ComboBox23
        '
        Me.ComboBox23.AccessibleDescription = Nothing
        Me.ComboBox23.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox23, "ComboBox23")
        Me.ComboBox23.BackgroundImage = Nothing
        Me.ComboBox23.Font = Nothing
        Me.ComboBox23.FormattingEnabled = True
        Me.ComboBox23.Items.AddRange(New Object() {resources.GetString("ComboBox23.Items"), resources.GetString("ComboBox23.Items1"), resources.GetString("ComboBox23.Items2")})
        Me.ComboBox23.Name = "ComboBox23"
        '
        'TextBox45
        '
        Me.TextBox45.AccessibleDescription = Nothing
        Me.TextBox45.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox45, "TextBox45")
        Me.TextBox45.BackgroundImage = Nothing
        Me.TextBox45.Font = Nothing
        Me.TextBox45.Name = "TextBox45"
        '
        'ComboBox24
        '
        Me.ComboBox24.AccessibleDescription = Nothing
        Me.ComboBox24.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox24, "ComboBox24")
        Me.ComboBox24.BackgroundImage = Nothing
        Me.ComboBox24.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox24.Font = Nothing
        Me.ComboBox24.FormattingEnabled = True
        Me.ComboBox24.Items.AddRange(New Object() {resources.GetString("ComboBox24.Items"), resources.GetString("ComboBox24.Items1"), resources.GetString("ComboBox24.Items2"), resources.GetString("ComboBox24.Items3"), resources.GetString("ComboBox24.Items4"), resources.GetString("ComboBox24.Items5"), resources.GetString("ComboBox24.Items6"), resources.GetString("ComboBox24.Items7"), resources.GetString("ComboBox24.Items8"), resources.GetString("ComboBox24.Items9"), resources.GetString("ComboBox24.Items10"), resources.GetString("ComboBox24.Items11"), resources.GetString("ComboBox24.Items12"), resources.GetString("ComboBox24.Items13"), resources.GetString("ComboBox24.Items14"), resources.GetString("ComboBox24.Items15"), resources.GetString("ComboBox24.Items16"), resources.GetString("ComboBox24.Items17"), resources.GetString("ComboBox24.Items18"), resources.GetString("ComboBox24.Items19"), resources.GetString("ComboBox24.Items20"), resources.GetString("ComboBox24.Items21"), resources.GetString("ComboBox24.Items22"), resources.GetString("ComboBox24.Items23"), resources.GetString("ComboBox24.Items24"), resources.GetString("ComboBox24.Items25"), resources.GetString("ComboBox24.Items26"), resources.GetString("ComboBox24.Items27"), resources.GetString("ComboBox24.Items28"), resources.GetString("ComboBox24.Items29"), resources.GetString("ComboBox24.Items30"), resources.GetString("ComboBox24.Items31"), resources.GetString("ComboBox24.Items32"), resources.GetString("ComboBox24.Items33"), resources.GetString("ComboBox24.Items34"), resources.GetString("ComboBox24.Items35"), resources.GetString("ComboBox24.Items36"), resources.GetString("ComboBox24.Items37"), resources.GetString("ComboBox24.Items38"), resources.GetString("ComboBox24.Items39"), resources.GetString("ComboBox24.Items40"), resources.GetString("ComboBox24.Items41"), resources.GetString("ComboBox24.Items42"), resources.GetString("ComboBox24.Items43"), resources.GetString("ComboBox24.Items44"), resources.GetString("ComboBox24.Items45"), resources.GetString("ComboBox24.Items46"), resources.GetString("ComboBox24.Items47"), resources.GetString("ComboBox24.Items48"), resources.GetString("ComboBox24.Items49"), resources.GetString("ComboBox24.Items50"), resources.GetString("ComboBox24.Items51"), resources.GetString("ComboBox24.Items52"), resources.GetString("ComboBox24.Items53"), resources.GetString("ComboBox24.Items54"), resources.GetString("ComboBox24.Items55"), resources.GetString("ComboBox24.Items56"), resources.GetString("ComboBox24.Items57"), resources.GetString("ComboBox24.Items58"), resources.GetString("ComboBox24.Items59"), resources.GetString("ComboBox24.Items60"), resources.GetString("ComboBox24.Items61"), resources.GetString("ComboBox24.Items62"), resources.GetString("ComboBox24.Items63"), resources.GetString("ComboBox24.Items64"), resources.GetString("ComboBox24.Items65"), resources.GetString("ComboBox24.Items66"), resources.GetString("ComboBox24.Items67"), resources.GetString("ComboBox24.Items68"), resources.GetString("ComboBox24.Items69"), resources.GetString("ComboBox24.Items70"), resources.GetString("ComboBox24.Items71"), resources.GetString("ComboBox24.Items72"), resources.GetString("ComboBox24.Items73"), resources.GetString("ComboBox24.Items74"), resources.GetString("ComboBox24.Items75"), resources.GetString("ComboBox24.Items76"), resources.GetString("ComboBox24.Items77"), resources.GetString("ComboBox24.Items78"), resources.GetString("ComboBox24.Items79"), resources.GetString("ComboBox24.Items80"), resources.GetString("ComboBox24.Items81"), resources.GetString("ComboBox24.Items82"), resources.GetString("ComboBox24.Items83"), resources.GetString("ComboBox24.Items84"), resources.GetString("ComboBox24.Items85"), resources.GetString("ComboBox24.Items86"), resources.GetString("ComboBox24.Items87"), resources.GetString("ComboBox24.Items88"), resources.GetString("ComboBox24.Items89"), resources.GetString("ComboBox24.Items90"), resources.GetString("ComboBox24.Items91"), resources.GetString("ComboBox24.Items92"), resources.GetString("ComboBox24.Items93"), resources.GetString("ComboBox24.Items94"), resources.GetString("ComboBox24.Items95"), resources.GetString("ComboBox24.Items96"), resources.GetString("ComboBox24.Items97"), resources.GetString("ComboBox24.Items98"), resources.GetString("ComboBox24.Items99"), resources.GetString("ComboBox24.Items100"), resources.GetString("ComboBox24.Items101"), resources.GetString("ComboBox24.Items102"), resources.GetString("ComboBox24.Items103"), resources.GetString("ComboBox24.Items104"), resources.GetString("ComboBox24.Items105"), resources.GetString("ComboBox24.Items106"), resources.GetString("ComboBox24.Items107"), resources.GetString("ComboBox24.Items108"), resources.GetString("ComboBox24.Items109"), resources.GetString("ComboBox24.Items110"), resources.GetString("ComboBox24.Items111"), resources.GetString("ComboBox24.Items112"), resources.GetString("ComboBox24.Items113"), resources.GetString("ComboBox24.Items114"), resources.GetString("ComboBox24.Items115"), resources.GetString("ComboBox24.Items116"), resources.GetString("ComboBox24.Items117"), resources.GetString("ComboBox24.Items118"), resources.GetString("ComboBox24.Items119"), resources.GetString("ComboBox24.Items120"), resources.GetString("ComboBox24.Items121"), resources.GetString("ComboBox24.Items122"), resources.GetString("ComboBox24.Items123"), resources.GetString("ComboBox24.Items124"), resources.GetString("ComboBox24.Items125"), resources.GetString("ComboBox24.Items126"), resources.GetString("ComboBox24.Items127"), resources.GetString("ComboBox24.Items128"), resources.GetString("ComboBox24.Items129"), resources.GetString("ComboBox24.Items130"), resources.GetString("ComboBox24.Items131"), resources.GetString("ComboBox24.Items132"), resources.GetString("ComboBox24.Items133"), resources.GetString("ComboBox24.Items134"), resources.GetString("ComboBox24.Items135"), resources.GetString("ComboBox24.Items136"), resources.GetString("ComboBox24.Items137"), resources.GetString("ComboBox24.Items138"), resources.GetString("ComboBox24.Items139"), resources.GetString("ComboBox24.Items140"), resources.GetString("ComboBox24.Items141"), resources.GetString("ComboBox24.Items142"), resources.GetString("ComboBox24.Items143"), resources.GetString("ComboBox24.Items144"), resources.GetString("ComboBox24.Items145"), resources.GetString("ComboBox24.Items146"), resources.GetString("ComboBox24.Items147"), resources.GetString("ComboBox24.Items148"), resources.GetString("ComboBox24.Items149"), resources.GetString("ComboBox24.Items150"), resources.GetString("ComboBox24.Items151"), resources.GetString("ComboBox24.Items152"), resources.GetString("ComboBox24.Items153"), resources.GetString("ComboBox24.Items154"), resources.GetString("ComboBox24.Items155"), resources.GetString("ComboBox24.Items156"), resources.GetString("ComboBox24.Items157"), resources.GetString("ComboBox24.Items158"), resources.GetString("ComboBox24.Items159"), resources.GetString("ComboBox24.Items160"), resources.GetString("ComboBox24.Items161"), resources.GetString("ComboBox24.Items162"), resources.GetString("ComboBox24.Items163"), resources.GetString("ComboBox24.Items164"), resources.GetString("ComboBox24.Items165"), resources.GetString("ComboBox24.Items166"), resources.GetString("ComboBox24.Items167"), resources.GetString("ComboBox24.Items168"), resources.GetString("ComboBox24.Items169"), resources.GetString("ComboBox24.Items170"), resources.GetString("ComboBox24.Items171"), resources.GetString("ComboBox24.Items172"), resources.GetString("ComboBox24.Items173"), resources.GetString("ComboBox24.Items174"), resources.GetString("ComboBox24.Items175"), resources.GetString("ComboBox24.Items176"), resources.GetString("ComboBox24.Items177"), resources.GetString("ComboBox24.Items178"), resources.GetString("ComboBox24.Items179"), resources.GetString("ComboBox24.Items180"), resources.GetString("ComboBox24.Items181"), resources.GetString("ComboBox24.Items182"), resources.GetString("ComboBox24.Items183"), resources.GetString("ComboBox24.Items184"), resources.GetString("ComboBox24.Items185"), resources.GetString("ComboBox24.Items186"), resources.GetString("ComboBox24.Items187"), resources.GetString("ComboBox24.Items188"), resources.GetString("ComboBox24.Items189"), resources.GetString("ComboBox24.Items190"), resources.GetString("ComboBox24.Items191"), resources.GetString("ComboBox24.Items192"), resources.GetString("ComboBox24.Items193"), resources.GetString("ComboBox24.Items194"), resources.GetString("ComboBox24.Items195"), resources.GetString("ComboBox24.Items196")})
        Me.ComboBox24.Name = "ComboBox24"
        '
        'TextBox46
        '
        Me.TextBox46.AccessibleDescription = Nothing
        Me.TextBox46.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox46, "TextBox46")
        Me.TextBox46.BackgroundImage = Nothing
        Me.TextBox46.Font = Nothing
        Me.TextBox46.Name = "TextBox46"
        '
        'ComboBox25
        '
        Me.ComboBox25.AccessibleDescription = Nothing
        Me.ComboBox25.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox25, "ComboBox25")
        Me.ComboBox25.BackgroundImage = Nothing
        Me.ComboBox25.Font = Nothing
        Me.ComboBox25.FormattingEnabled = True
        Me.ComboBox25.Items.AddRange(New Object() {resources.GetString("ComboBox25.Items"), resources.GetString("ComboBox25.Items1"), resources.GetString("ComboBox25.Items2")})
        Me.ComboBox25.Name = "ComboBox25"
        '
        'TextBox47
        '
        Me.TextBox47.AccessibleDescription = Nothing
        Me.TextBox47.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox47, "TextBox47")
        Me.TextBox47.BackgroundImage = Nothing
        Me.TextBox47.Font = Nothing
        Me.TextBox47.Name = "TextBox47"
        '
        'TextBox48
        '
        Me.TextBox48.AccessibleDescription = Nothing
        Me.TextBox48.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox48, "TextBox48")
        Me.TextBox48.BackgroundImage = Nothing
        Me.TextBox48.Font = Nothing
        Me.TextBox48.Name = "TextBox48"
        '
        'TextBox49
        '
        Me.TextBox49.AccessibleDescription = Nothing
        Me.TextBox49.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox49, "TextBox49")
        Me.TextBox49.BackgroundImage = Nothing
        Me.TextBox49.Font = Nothing
        Me.TextBox49.Name = "TextBox49"
        '
        'TextBox50
        '
        Me.TextBox50.AccessibleDescription = Nothing
        Me.TextBox50.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox50, "TextBox50")
        Me.TextBox50.BackgroundImage = Nothing
        Me.TextBox50.Font = Nothing
        Me.TextBox50.Name = "TextBox50"
        '
        'ComboBox26
        '
        Me.ComboBox26.AccessibleDescription = Nothing
        Me.ComboBox26.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox26, "ComboBox26")
        Me.ComboBox26.BackgroundImage = Nothing
        Me.ComboBox26.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox26.Font = Nothing
        Me.ComboBox26.FormattingEnabled = True
        Me.ComboBox26.Items.AddRange(New Object() {resources.GetString("ComboBox26.Items"), resources.GetString("ComboBox26.Items1"), resources.GetString("ComboBox26.Items2"), resources.GetString("ComboBox26.Items3"), resources.GetString("ComboBox26.Items4"), resources.GetString("ComboBox26.Items5"), resources.GetString("ComboBox26.Items6"), resources.GetString("ComboBox26.Items7"), resources.GetString("ComboBox26.Items8"), resources.GetString("ComboBox26.Items9"), resources.GetString("ComboBox26.Items10"), resources.GetString("ComboBox26.Items11"), resources.GetString("ComboBox26.Items12"), resources.GetString("ComboBox26.Items13"), resources.GetString("ComboBox26.Items14"), resources.GetString("ComboBox26.Items15"), resources.GetString("ComboBox26.Items16"), resources.GetString("ComboBox26.Items17"), resources.GetString("ComboBox26.Items18"), resources.GetString("ComboBox26.Items19"), resources.GetString("ComboBox26.Items20"), resources.GetString("ComboBox26.Items21"), resources.GetString("ComboBox26.Items22"), resources.GetString("ComboBox26.Items23"), resources.GetString("ComboBox26.Items24"), resources.GetString("ComboBox26.Items25"), resources.GetString("ComboBox26.Items26"), resources.GetString("ComboBox26.Items27"), resources.GetString("ComboBox26.Items28"), resources.GetString("ComboBox26.Items29"), resources.GetString("ComboBox26.Items30"), resources.GetString("ComboBox26.Items31"), resources.GetString("ComboBox26.Items32"), resources.GetString("ComboBox26.Items33"), resources.GetString("ComboBox26.Items34"), resources.GetString("ComboBox26.Items35"), resources.GetString("ComboBox26.Items36"), resources.GetString("ComboBox26.Items37"), resources.GetString("ComboBox26.Items38"), resources.GetString("ComboBox26.Items39"), resources.GetString("ComboBox26.Items40"), resources.GetString("ComboBox26.Items41"), resources.GetString("ComboBox26.Items42"), resources.GetString("ComboBox26.Items43"), resources.GetString("ComboBox26.Items44"), resources.GetString("ComboBox26.Items45"), resources.GetString("ComboBox26.Items46"), resources.GetString("ComboBox26.Items47"), resources.GetString("ComboBox26.Items48"), resources.GetString("ComboBox26.Items49"), resources.GetString("ComboBox26.Items50"), resources.GetString("ComboBox26.Items51"), resources.GetString("ComboBox26.Items52"), resources.GetString("ComboBox26.Items53"), resources.GetString("ComboBox26.Items54"), resources.GetString("ComboBox26.Items55"), resources.GetString("ComboBox26.Items56"), resources.GetString("ComboBox26.Items57"), resources.GetString("ComboBox26.Items58"), resources.GetString("ComboBox26.Items59"), resources.GetString("ComboBox26.Items60"), resources.GetString("ComboBox26.Items61"), resources.GetString("ComboBox26.Items62"), resources.GetString("ComboBox26.Items63"), resources.GetString("ComboBox26.Items64"), resources.GetString("ComboBox26.Items65"), resources.GetString("ComboBox26.Items66"), resources.GetString("ComboBox26.Items67"), resources.GetString("ComboBox26.Items68"), resources.GetString("ComboBox26.Items69"), resources.GetString("ComboBox26.Items70"), resources.GetString("ComboBox26.Items71"), resources.GetString("ComboBox26.Items72"), resources.GetString("ComboBox26.Items73"), resources.GetString("ComboBox26.Items74"), resources.GetString("ComboBox26.Items75"), resources.GetString("ComboBox26.Items76"), resources.GetString("ComboBox26.Items77"), resources.GetString("ComboBox26.Items78"), resources.GetString("ComboBox26.Items79"), resources.GetString("ComboBox26.Items80"), resources.GetString("ComboBox26.Items81"), resources.GetString("ComboBox26.Items82"), resources.GetString("ComboBox26.Items83"), resources.GetString("ComboBox26.Items84"), resources.GetString("ComboBox26.Items85"), resources.GetString("ComboBox26.Items86"), resources.GetString("ComboBox26.Items87"), resources.GetString("ComboBox26.Items88"), resources.GetString("ComboBox26.Items89"), resources.GetString("ComboBox26.Items90"), resources.GetString("ComboBox26.Items91"), resources.GetString("ComboBox26.Items92"), resources.GetString("ComboBox26.Items93"), resources.GetString("ComboBox26.Items94"), resources.GetString("ComboBox26.Items95"), resources.GetString("ComboBox26.Items96"), resources.GetString("ComboBox26.Items97"), resources.GetString("ComboBox26.Items98"), resources.GetString("ComboBox26.Items99"), resources.GetString("ComboBox26.Items100"), resources.GetString("ComboBox26.Items101"), resources.GetString("ComboBox26.Items102"), resources.GetString("ComboBox26.Items103"), resources.GetString("ComboBox26.Items104"), resources.GetString("ComboBox26.Items105"), resources.GetString("ComboBox26.Items106"), resources.GetString("ComboBox26.Items107"), resources.GetString("ComboBox26.Items108"), resources.GetString("ComboBox26.Items109"), resources.GetString("ComboBox26.Items110"), resources.GetString("ComboBox26.Items111"), resources.GetString("ComboBox26.Items112"), resources.GetString("ComboBox26.Items113"), resources.GetString("ComboBox26.Items114"), resources.GetString("ComboBox26.Items115"), resources.GetString("ComboBox26.Items116"), resources.GetString("ComboBox26.Items117"), resources.GetString("ComboBox26.Items118"), resources.GetString("ComboBox26.Items119"), resources.GetString("ComboBox26.Items120"), resources.GetString("ComboBox26.Items121"), resources.GetString("ComboBox26.Items122"), resources.GetString("ComboBox26.Items123"), resources.GetString("ComboBox26.Items124"), resources.GetString("ComboBox26.Items125"), resources.GetString("ComboBox26.Items126"), resources.GetString("ComboBox26.Items127"), resources.GetString("ComboBox26.Items128"), resources.GetString("ComboBox26.Items129"), resources.GetString("ComboBox26.Items130"), resources.GetString("ComboBox26.Items131"), resources.GetString("ComboBox26.Items132"), resources.GetString("ComboBox26.Items133"), resources.GetString("ComboBox26.Items134"), resources.GetString("ComboBox26.Items135"), resources.GetString("ComboBox26.Items136"), resources.GetString("ComboBox26.Items137"), resources.GetString("ComboBox26.Items138"), resources.GetString("ComboBox26.Items139"), resources.GetString("ComboBox26.Items140"), resources.GetString("ComboBox26.Items141"), resources.GetString("ComboBox26.Items142"), resources.GetString("ComboBox26.Items143"), resources.GetString("ComboBox26.Items144"), resources.GetString("ComboBox26.Items145"), resources.GetString("ComboBox26.Items146"), resources.GetString("ComboBox26.Items147"), resources.GetString("ComboBox26.Items148"), resources.GetString("ComboBox26.Items149"), resources.GetString("ComboBox26.Items150"), resources.GetString("ComboBox26.Items151"), resources.GetString("ComboBox26.Items152"), resources.GetString("ComboBox26.Items153"), resources.GetString("ComboBox26.Items154"), resources.GetString("ComboBox26.Items155"), resources.GetString("ComboBox26.Items156"), resources.GetString("ComboBox26.Items157"), resources.GetString("ComboBox26.Items158"), resources.GetString("ComboBox26.Items159"), resources.GetString("ComboBox26.Items160"), resources.GetString("ComboBox26.Items161"), resources.GetString("ComboBox26.Items162"), resources.GetString("ComboBox26.Items163"), resources.GetString("ComboBox26.Items164"), resources.GetString("ComboBox26.Items165"), resources.GetString("ComboBox26.Items166"), resources.GetString("ComboBox26.Items167"), resources.GetString("ComboBox26.Items168"), resources.GetString("ComboBox26.Items169"), resources.GetString("ComboBox26.Items170"), resources.GetString("ComboBox26.Items171"), resources.GetString("ComboBox26.Items172"), resources.GetString("ComboBox26.Items173"), resources.GetString("ComboBox26.Items174"), resources.GetString("ComboBox26.Items175"), resources.GetString("ComboBox26.Items176"), resources.GetString("ComboBox26.Items177"), resources.GetString("ComboBox26.Items178"), resources.GetString("ComboBox26.Items179"), resources.GetString("ComboBox26.Items180"), resources.GetString("ComboBox26.Items181"), resources.GetString("ComboBox26.Items182"), resources.GetString("ComboBox26.Items183"), resources.GetString("ComboBox26.Items184"), resources.GetString("ComboBox26.Items185"), resources.GetString("ComboBox26.Items186"), resources.GetString("ComboBox26.Items187"), resources.GetString("ComboBox26.Items188"), resources.GetString("ComboBox26.Items189"), resources.GetString("ComboBox26.Items190"), resources.GetString("ComboBox26.Items191"), resources.GetString("ComboBox26.Items192"), resources.GetString("ComboBox26.Items193"), resources.GetString("ComboBox26.Items194"), resources.GetString("ComboBox26.Items195"), resources.GetString("ComboBox26.Items196")})
        Me.ComboBox26.Name = "ComboBox26"
        '
        'TextBox51
        '
        Me.TextBox51.AccessibleDescription = Nothing
        Me.TextBox51.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox51, "TextBox51")
        Me.TextBox51.BackgroundImage = Nothing
        Me.TextBox51.Font = Nothing
        Me.TextBox51.Name = "TextBox51"
        '
        'ComboBox27
        '
        Me.ComboBox27.AccessibleDescription = Nothing
        Me.ComboBox27.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox27, "ComboBox27")
        Me.ComboBox27.BackgroundImage = Nothing
        Me.ComboBox27.Font = Nothing
        Me.ComboBox27.FormattingEnabled = True
        Me.ComboBox27.Items.AddRange(New Object() {resources.GetString("ComboBox27.Items"), resources.GetString("ComboBox27.Items1"), resources.GetString("ComboBox27.Items2")})
        Me.ComboBox27.Name = "ComboBox27"
        '
        'TextBox52
        '
        Me.TextBox52.AccessibleDescription = Nothing
        Me.TextBox52.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox52, "TextBox52")
        Me.TextBox52.BackgroundImage = Nothing
        Me.TextBox52.Font = Nothing
        Me.TextBox52.Name = "TextBox52"
        '
        'ComboBox28
        '
        Me.ComboBox28.AccessibleDescription = Nothing
        Me.ComboBox28.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox28, "ComboBox28")
        Me.ComboBox28.BackgroundImage = Nothing
        Me.ComboBox28.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox28.Font = Nothing
        Me.ComboBox28.FormattingEnabled = True
        Me.ComboBox28.Items.AddRange(New Object() {resources.GetString("ComboBox28.Items"), resources.GetString("ComboBox28.Items1"), resources.GetString("ComboBox28.Items2"), resources.GetString("ComboBox28.Items3"), resources.GetString("ComboBox28.Items4"), resources.GetString("ComboBox28.Items5"), resources.GetString("ComboBox28.Items6"), resources.GetString("ComboBox28.Items7"), resources.GetString("ComboBox28.Items8"), resources.GetString("ComboBox28.Items9"), resources.GetString("ComboBox28.Items10"), resources.GetString("ComboBox28.Items11"), resources.GetString("ComboBox28.Items12"), resources.GetString("ComboBox28.Items13"), resources.GetString("ComboBox28.Items14"), resources.GetString("ComboBox28.Items15"), resources.GetString("ComboBox28.Items16"), resources.GetString("ComboBox28.Items17"), resources.GetString("ComboBox28.Items18"), resources.GetString("ComboBox28.Items19"), resources.GetString("ComboBox28.Items20"), resources.GetString("ComboBox28.Items21"), resources.GetString("ComboBox28.Items22"), resources.GetString("ComboBox28.Items23"), resources.GetString("ComboBox28.Items24"), resources.GetString("ComboBox28.Items25"), resources.GetString("ComboBox28.Items26"), resources.GetString("ComboBox28.Items27"), resources.GetString("ComboBox28.Items28"), resources.GetString("ComboBox28.Items29"), resources.GetString("ComboBox28.Items30"), resources.GetString("ComboBox28.Items31"), resources.GetString("ComboBox28.Items32"), resources.GetString("ComboBox28.Items33"), resources.GetString("ComboBox28.Items34"), resources.GetString("ComboBox28.Items35"), resources.GetString("ComboBox28.Items36"), resources.GetString("ComboBox28.Items37"), resources.GetString("ComboBox28.Items38"), resources.GetString("ComboBox28.Items39"), resources.GetString("ComboBox28.Items40"), resources.GetString("ComboBox28.Items41"), resources.GetString("ComboBox28.Items42"), resources.GetString("ComboBox28.Items43"), resources.GetString("ComboBox28.Items44"), resources.GetString("ComboBox28.Items45"), resources.GetString("ComboBox28.Items46"), resources.GetString("ComboBox28.Items47"), resources.GetString("ComboBox28.Items48"), resources.GetString("ComboBox28.Items49"), resources.GetString("ComboBox28.Items50"), resources.GetString("ComboBox28.Items51"), resources.GetString("ComboBox28.Items52"), resources.GetString("ComboBox28.Items53"), resources.GetString("ComboBox28.Items54"), resources.GetString("ComboBox28.Items55"), resources.GetString("ComboBox28.Items56"), resources.GetString("ComboBox28.Items57"), resources.GetString("ComboBox28.Items58"), resources.GetString("ComboBox28.Items59"), resources.GetString("ComboBox28.Items60"), resources.GetString("ComboBox28.Items61"), resources.GetString("ComboBox28.Items62"), resources.GetString("ComboBox28.Items63"), resources.GetString("ComboBox28.Items64"), resources.GetString("ComboBox28.Items65"), resources.GetString("ComboBox28.Items66"), resources.GetString("ComboBox28.Items67"), resources.GetString("ComboBox28.Items68"), resources.GetString("ComboBox28.Items69"), resources.GetString("ComboBox28.Items70"), resources.GetString("ComboBox28.Items71"), resources.GetString("ComboBox28.Items72"), resources.GetString("ComboBox28.Items73"), resources.GetString("ComboBox28.Items74"), resources.GetString("ComboBox28.Items75"), resources.GetString("ComboBox28.Items76"), resources.GetString("ComboBox28.Items77"), resources.GetString("ComboBox28.Items78"), resources.GetString("ComboBox28.Items79"), resources.GetString("ComboBox28.Items80"), resources.GetString("ComboBox28.Items81"), resources.GetString("ComboBox28.Items82"), resources.GetString("ComboBox28.Items83"), resources.GetString("ComboBox28.Items84"), resources.GetString("ComboBox28.Items85"), resources.GetString("ComboBox28.Items86"), resources.GetString("ComboBox28.Items87"), resources.GetString("ComboBox28.Items88"), resources.GetString("ComboBox28.Items89"), resources.GetString("ComboBox28.Items90"), resources.GetString("ComboBox28.Items91"), resources.GetString("ComboBox28.Items92"), resources.GetString("ComboBox28.Items93"), resources.GetString("ComboBox28.Items94"), resources.GetString("ComboBox28.Items95"), resources.GetString("ComboBox28.Items96"), resources.GetString("ComboBox28.Items97"), resources.GetString("ComboBox28.Items98"), resources.GetString("ComboBox28.Items99"), resources.GetString("ComboBox28.Items100"), resources.GetString("ComboBox28.Items101"), resources.GetString("ComboBox28.Items102"), resources.GetString("ComboBox28.Items103"), resources.GetString("ComboBox28.Items104"), resources.GetString("ComboBox28.Items105"), resources.GetString("ComboBox28.Items106"), resources.GetString("ComboBox28.Items107"), resources.GetString("ComboBox28.Items108"), resources.GetString("ComboBox28.Items109"), resources.GetString("ComboBox28.Items110"), resources.GetString("ComboBox28.Items111"), resources.GetString("ComboBox28.Items112"), resources.GetString("ComboBox28.Items113"), resources.GetString("ComboBox28.Items114"), resources.GetString("ComboBox28.Items115"), resources.GetString("ComboBox28.Items116"), resources.GetString("ComboBox28.Items117"), resources.GetString("ComboBox28.Items118"), resources.GetString("ComboBox28.Items119"), resources.GetString("ComboBox28.Items120"), resources.GetString("ComboBox28.Items121"), resources.GetString("ComboBox28.Items122"), resources.GetString("ComboBox28.Items123"), resources.GetString("ComboBox28.Items124"), resources.GetString("ComboBox28.Items125"), resources.GetString("ComboBox28.Items126"), resources.GetString("ComboBox28.Items127"), resources.GetString("ComboBox28.Items128"), resources.GetString("ComboBox28.Items129"), resources.GetString("ComboBox28.Items130"), resources.GetString("ComboBox28.Items131"), resources.GetString("ComboBox28.Items132"), resources.GetString("ComboBox28.Items133"), resources.GetString("ComboBox28.Items134"), resources.GetString("ComboBox28.Items135"), resources.GetString("ComboBox28.Items136"), resources.GetString("ComboBox28.Items137"), resources.GetString("ComboBox28.Items138"), resources.GetString("ComboBox28.Items139"), resources.GetString("ComboBox28.Items140"), resources.GetString("ComboBox28.Items141"), resources.GetString("ComboBox28.Items142"), resources.GetString("ComboBox28.Items143"), resources.GetString("ComboBox28.Items144"), resources.GetString("ComboBox28.Items145"), resources.GetString("ComboBox28.Items146"), resources.GetString("ComboBox28.Items147"), resources.GetString("ComboBox28.Items148"), resources.GetString("ComboBox28.Items149"), resources.GetString("ComboBox28.Items150"), resources.GetString("ComboBox28.Items151"), resources.GetString("ComboBox28.Items152"), resources.GetString("ComboBox28.Items153"), resources.GetString("ComboBox28.Items154"), resources.GetString("ComboBox28.Items155"), resources.GetString("ComboBox28.Items156"), resources.GetString("ComboBox28.Items157"), resources.GetString("ComboBox28.Items158"), resources.GetString("ComboBox28.Items159"), resources.GetString("ComboBox28.Items160"), resources.GetString("ComboBox28.Items161"), resources.GetString("ComboBox28.Items162"), resources.GetString("ComboBox28.Items163"), resources.GetString("ComboBox28.Items164"), resources.GetString("ComboBox28.Items165"), resources.GetString("ComboBox28.Items166"), resources.GetString("ComboBox28.Items167"), resources.GetString("ComboBox28.Items168"), resources.GetString("ComboBox28.Items169"), resources.GetString("ComboBox28.Items170"), resources.GetString("ComboBox28.Items171"), resources.GetString("ComboBox28.Items172"), resources.GetString("ComboBox28.Items173"), resources.GetString("ComboBox28.Items174"), resources.GetString("ComboBox28.Items175"), resources.GetString("ComboBox28.Items176"), resources.GetString("ComboBox28.Items177"), resources.GetString("ComboBox28.Items178"), resources.GetString("ComboBox28.Items179"), resources.GetString("ComboBox28.Items180"), resources.GetString("ComboBox28.Items181"), resources.GetString("ComboBox28.Items182"), resources.GetString("ComboBox28.Items183"), resources.GetString("ComboBox28.Items184"), resources.GetString("ComboBox28.Items185"), resources.GetString("ComboBox28.Items186"), resources.GetString("ComboBox28.Items187"), resources.GetString("ComboBox28.Items188"), resources.GetString("ComboBox28.Items189"), resources.GetString("ComboBox28.Items190"), resources.GetString("ComboBox28.Items191"), resources.GetString("ComboBox28.Items192"), resources.GetString("ComboBox28.Items193"), resources.GetString("ComboBox28.Items194"), resources.GetString("ComboBox28.Items195"), resources.GetString("ComboBox28.Items196")})
        Me.ComboBox28.Name = "ComboBox28"
        '
        'TextBox53
        '
        Me.TextBox53.AccessibleDescription = Nothing
        Me.TextBox53.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox53, "TextBox53")
        Me.TextBox53.BackgroundImage = Nothing
        Me.TextBox53.Font = Nothing
        Me.TextBox53.Name = "TextBox53"
        '
        'ComboBox29
        '
        Me.ComboBox29.AccessibleDescription = Nothing
        Me.ComboBox29.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox29, "ComboBox29")
        Me.ComboBox29.BackgroundImage = Nothing
        Me.ComboBox29.Font = Nothing
        Me.ComboBox29.FormattingEnabled = True
        Me.ComboBox29.Items.AddRange(New Object() {resources.GetString("ComboBox29.Items"), resources.GetString("ComboBox29.Items1"), resources.GetString("ComboBox29.Items2")})
        Me.ComboBox29.Name = "ComboBox29"
        '
        'TextBox54
        '
        Me.TextBox54.AccessibleDescription = Nothing
        Me.TextBox54.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox54, "TextBox54")
        Me.TextBox54.BackgroundImage = Nothing
        Me.TextBox54.Font = Nothing
        Me.TextBox54.Name = "TextBox54"
        '
        'ComboBox30
        '
        Me.ComboBox30.AccessibleDescription = Nothing
        Me.ComboBox30.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox30, "ComboBox30")
        Me.ComboBox30.BackgroundImage = Nothing
        Me.ComboBox30.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox30.Font = Nothing
        Me.ComboBox30.FormattingEnabled = True
        Me.ComboBox30.Items.AddRange(New Object() {resources.GetString("ComboBox30.Items"), resources.GetString("ComboBox30.Items1"), resources.GetString("ComboBox30.Items2"), resources.GetString("ComboBox30.Items3"), resources.GetString("ComboBox30.Items4"), resources.GetString("ComboBox30.Items5"), resources.GetString("ComboBox30.Items6"), resources.GetString("ComboBox30.Items7"), resources.GetString("ComboBox30.Items8"), resources.GetString("ComboBox30.Items9"), resources.GetString("ComboBox30.Items10"), resources.GetString("ComboBox30.Items11"), resources.GetString("ComboBox30.Items12"), resources.GetString("ComboBox30.Items13"), resources.GetString("ComboBox30.Items14"), resources.GetString("ComboBox30.Items15"), resources.GetString("ComboBox30.Items16"), resources.GetString("ComboBox30.Items17"), resources.GetString("ComboBox30.Items18"), resources.GetString("ComboBox30.Items19"), resources.GetString("ComboBox30.Items20"), resources.GetString("ComboBox30.Items21"), resources.GetString("ComboBox30.Items22"), resources.GetString("ComboBox30.Items23"), resources.GetString("ComboBox30.Items24"), resources.GetString("ComboBox30.Items25"), resources.GetString("ComboBox30.Items26"), resources.GetString("ComboBox30.Items27"), resources.GetString("ComboBox30.Items28"), resources.GetString("ComboBox30.Items29"), resources.GetString("ComboBox30.Items30"), resources.GetString("ComboBox30.Items31"), resources.GetString("ComboBox30.Items32"), resources.GetString("ComboBox30.Items33"), resources.GetString("ComboBox30.Items34"), resources.GetString("ComboBox30.Items35"), resources.GetString("ComboBox30.Items36"), resources.GetString("ComboBox30.Items37"), resources.GetString("ComboBox30.Items38"), resources.GetString("ComboBox30.Items39"), resources.GetString("ComboBox30.Items40"), resources.GetString("ComboBox30.Items41"), resources.GetString("ComboBox30.Items42"), resources.GetString("ComboBox30.Items43"), resources.GetString("ComboBox30.Items44"), resources.GetString("ComboBox30.Items45"), resources.GetString("ComboBox30.Items46"), resources.GetString("ComboBox30.Items47"), resources.GetString("ComboBox30.Items48"), resources.GetString("ComboBox30.Items49"), resources.GetString("ComboBox30.Items50"), resources.GetString("ComboBox30.Items51"), resources.GetString("ComboBox30.Items52"), resources.GetString("ComboBox30.Items53"), resources.GetString("ComboBox30.Items54"), resources.GetString("ComboBox30.Items55"), resources.GetString("ComboBox30.Items56"), resources.GetString("ComboBox30.Items57"), resources.GetString("ComboBox30.Items58"), resources.GetString("ComboBox30.Items59"), resources.GetString("ComboBox30.Items60"), resources.GetString("ComboBox30.Items61"), resources.GetString("ComboBox30.Items62"), resources.GetString("ComboBox30.Items63"), resources.GetString("ComboBox30.Items64"), resources.GetString("ComboBox30.Items65"), resources.GetString("ComboBox30.Items66"), resources.GetString("ComboBox30.Items67"), resources.GetString("ComboBox30.Items68"), resources.GetString("ComboBox30.Items69"), resources.GetString("ComboBox30.Items70"), resources.GetString("ComboBox30.Items71"), resources.GetString("ComboBox30.Items72"), resources.GetString("ComboBox30.Items73"), resources.GetString("ComboBox30.Items74"), resources.GetString("ComboBox30.Items75"), resources.GetString("ComboBox30.Items76"), resources.GetString("ComboBox30.Items77"), resources.GetString("ComboBox30.Items78"), resources.GetString("ComboBox30.Items79"), resources.GetString("ComboBox30.Items80"), resources.GetString("ComboBox30.Items81"), resources.GetString("ComboBox30.Items82"), resources.GetString("ComboBox30.Items83"), resources.GetString("ComboBox30.Items84"), resources.GetString("ComboBox30.Items85"), resources.GetString("ComboBox30.Items86"), resources.GetString("ComboBox30.Items87"), resources.GetString("ComboBox30.Items88"), resources.GetString("ComboBox30.Items89"), resources.GetString("ComboBox30.Items90"), resources.GetString("ComboBox30.Items91"), resources.GetString("ComboBox30.Items92"), resources.GetString("ComboBox30.Items93"), resources.GetString("ComboBox30.Items94"), resources.GetString("ComboBox30.Items95"), resources.GetString("ComboBox30.Items96"), resources.GetString("ComboBox30.Items97"), resources.GetString("ComboBox30.Items98"), resources.GetString("ComboBox30.Items99"), resources.GetString("ComboBox30.Items100"), resources.GetString("ComboBox30.Items101"), resources.GetString("ComboBox30.Items102"), resources.GetString("ComboBox30.Items103"), resources.GetString("ComboBox30.Items104"), resources.GetString("ComboBox30.Items105"), resources.GetString("ComboBox30.Items106"), resources.GetString("ComboBox30.Items107"), resources.GetString("ComboBox30.Items108"), resources.GetString("ComboBox30.Items109"), resources.GetString("ComboBox30.Items110"), resources.GetString("ComboBox30.Items111"), resources.GetString("ComboBox30.Items112"), resources.GetString("ComboBox30.Items113"), resources.GetString("ComboBox30.Items114"), resources.GetString("ComboBox30.Items115"), resources.GetString("ComboBox30.Items116"), resources.GetString("ComboBox30.Items117"), resources.GetString("ComboBox30.Items118"), resources.GetString("ComboBox30.Items119"), resources.GetString("ComboBox30.Items120"), resources.GetString("ComboBox30.Items121"), resources.GetString("ComboBox30.Items122"), resources.GetString("ComboBox30.Items123"), resources.GetString("ComboBox30.Items124"), resources.GetString("ComboBox30.Items125"), resources.GetString("ComboBox30.Items126"), resources.GetString("ComboBox30.Items127"), resources.GetString("ComboBox30.Items128"), resources.GetString("ComboBox30.Items129"), resources.GetString("ComboBox30.Items130"), resources.GetString("ComboBox30.Items131"), resources.GetString("ComboBox30.Items132"), resources.GetString("ComboBox30.Items133"), resources.GetString("ComboBox30.Items134"), resources.GetString("ComboBox30.Items135"), resources.GetString("ComboBox30.Items136"), resources.GetString("ComboBox30.Items137"), resources.GetString("ComboBox30.Items138"), resources.GetString("ComboBox30.Items139"), resources.GetString("ComboBox30.Items140"), resources.GetString("ComboBox30.Items141"), resources.GetString("ComboBox30.Items142"), resources.GetString("ComboBox30.Items143"), resources.GetString("ComboBox30.Items144"), resources.GetString("ComboBox30.Items145"), resources.GetString("ComboBox30.Items146"), resources.GetString("ComboBox30.Items147"), resources.GetString("ComboBox30.Items148"), resources.GetString("ComboBox30.Items149"), resources.GetString("ComboBox30.Items150"), resources.GetString("ComboBox30.Items151"), resources.GetString("ComboBox30.Items152"), resources.GetString("ComboBox30.Items153"), resources.GetString("ComboBox30.Items154"), resources.GetString("ComboBox30.Items155"), resources.GetString("ComboBox30.Items156"), resources.GetString("ComboBox30.Items157"), resources.GetString("ComboBox30.Items158"), resources.GetString("ComboBox30.Items159"), resources.GetString("ComboBox30.Items160"), resources.GetString("ComboBox30.Items161"), resources.GetString("ComboBox30.Items162"), resources.GetString("ComboBox30.Items163"), resources.GetString("ComboBox30.Items164"), resources.GetString("ComboBox30.Items165"), resources.GetString("ComboBox30.Items166"), resources.GetString("ComboBox30.Items167"), resources.GetString("ComboBox30.Items168"), resources.GetString("ComboBox30.Items169"), resources.GetString("ComboBox30.Items170"), resources.GetString("ComboBox30.Items171"), resources.GetString("ComboBox30.Items172"), resources.GetString("ComboBox30.Items173"), resources.GetString("ComboBox30.Items174"), resources.GetString("ComboBox30.Items175"), resources.GetString("ComboBox30.Items176"), resources.GetString("ComboBox30.Items177"), resources.GetString("ComboBox30.Items178"), resources.GetString("ComboBox30.Items179"), resources.GetString("ComboBox30.Items180"), resources.GetString("ComboBox30.Items181"), resources.GetString("ComboBox30.Items182"), resources.GetString("ComboBox30.Items183"), resources.GetString("ComboBox30.Items184"), resources.GetString("ComboBox30.Items185"), resources.GetString("ComboBox30.Items186"), resources.GetString("ComboBox30.Items187"), resources.GetString("ComboBox30.Items188"), resources.GetString("ComboBox30.Items189"), resources.GetString("ComboBox30.Items190"), resources.GetString("ComboBox30.Items191"), resources.GetString("ComboBox30.Items192"), resources.GetString("ComboBox30.Items193"), resources.GetString("ComboBox30.Items194"), resources.GetString("ComboBox30.Items195"), resources.GetString("ComboBox30.Items196")})
        Me.ComboBox30.Name = "ComboBox30"
        '
        'TextBox55
        '
        Me.TextBox55.AccessibleDescription = Nothing
        Me.TextBox55.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox55, "TextBox55")
        Me.TextBox55.BackgroundImage = Nothing
        Me.TextBox55.Font = Nothing
        Me.TextBox55.Name = "TextBox55"
        '
        'ComboBox31
        '
        Me.ComboBox31.AccessibleDescription = Nothing
        Me.ComboBox31.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox31, "ComboBox31")
        Me.ComboBox31.BackgroundImage = Nothing
        Me.ComboBox31.Font = Nothing
        Me.ComboBox31.FormattingEnabled = True
        Me.ComboBox31.Items.AddRange(New Object() {resources.GetString("ComboBox31.Items"), resources.GetString("ComboBox31.Items1"), resources.GetString("ComboBox31.Items2")})
        Me.ComboBox31.Name = "ComboBox31"
        '
        'TextBox56
        '
        Me.TextBox56.AccessibleDescription = Nothing
        Me.TextBox56.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox56, "TextBox56")
        Me.TextBox56.BackgroundImage = Nothing
        Me.TextBox56.Font = Nothing
        Me.TextBox56.Name = "TextBox56"
        '
        'ComboBox32
        '
        Me.ComboBox32.AccessibleDescription = Nothing
        Me.ComboBox32.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox32, "ComboBox32")
        Me.ComboBox32.BackgroundImage = Nothing
        Me.ComboBox32.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox32.Font = Nothing
        Me.ComboBox32.FormattingEnabled = True
        Me.ComboBox32.Items.AddRange(New Object() {resources.GetString("ComboBox32.Items"), resources.GetString("ComboBox32.Items1"), resources.GetString("ComboBox32.Items2"), resources.GetString("ComboBox32.Items3"), resources.GetString("ComboBox32.Items4"), resources.GetString("ComboBox32.Items5"), resources.GetString("ComboBox32.Items6"), resources.GetString("ComboBox32.Items7"), resources.GetString("ComboBox32.Items8"), resources.GetString("ComboBox32.Items9"), resources.GetString("ComboBox32.Items10"), resources.GetString("ComboBox32.Items11"), resources.GetString("ComboBox32.Items12"), resources.GetString("ComboBox32.Items13"), resources.GetString("ComboBox32.Items14"), resources.GetString("ComboBox32.Items15"), resources.GetString("ComboBox32.Items16"), resources.GetString("ComboBox32.Items17"), resources.GetString("ComboBox32.Items18"), resources.GetString("ComboBox32.Items19"), resources.GetString("ComboBox32.Items20"), resources.GetString("ComboBox32.Items21"), resources.GetString("ComboBox32.Items22"), resources.GetString("ComboBox32.Items23"), resources.GetString("ComboBox32.Items24"), resources.GetString("ComboBox32.Items25"), resources.GetString("ComboBox32.Items26"), resources.GetString("ComboBox32.Items27"), resources.GetString("ComboBox32.Items28"), resources.GetString("ComboBox32.Items29"), resources.GetString("ComboBox32.Items30"), resources.GetString("ComboBox32.Items31"), resources.GetString("ComboBox32.Items32"), resources.GetString("ComboBox32.Items33"), resources.GetString("ComboBox32.Items34"), resources.GetString("ComboBox32.Items35"), resources.GetString("ComboBox32.Items36"), resources.GetString("ComboBox32.Items37"), resources.GetString("ComboBox32.Items38"), resources.GetString("ComboBox32.Items39"), resources.GetString("ComboBox32.Items40"), resources.GetString("ComboBox32.Items41"), resources.GetString("ComboBox32.Items42"), resources.GetString("ComboBox32.Items43"), resources.GetString("ComboBox32.Items44"), resources.GetString("ComboBox32.Items45"), resources.GetString("ComboBox32.Items46"), resources.GetString("ComboBox32.Items47"), resources.GetString("ComboBox32.Items48"), resources.GetString("ComboBox32.Items49"), resources.GetString("ComboBox32.Items50"), resources.GetString("ComboBox32.Items51"), resources.GetString("ComboBox32.Items52"), resources.GetString("ComboBox32.Items53"), resources.GetString("ComboBox32.Items54"), resources.GetString("ComboBox32.Items55"), resources.GetString("ComboBox32.Items56"), resources.GetString("ComboBox32.Items57"), resources.GetString("ComboBox32.Items58"), resources.GetString("ComboBox32.Items59"), resources.GetString("ComboBox32.Items60"), resources.GetString("ComboBox32.Items61"), resources.GetString("ComboBox32.Items62"), resources.GetString("ComboBox32.Items63"), resources.GetString("ComboBox32.Items64"), resources.GetString("ComboBox32.Items65"), resources.GetString("ComboBox32.Items66"), resources.GetString("ComboBox32.Items67"), resources.GetString("ComboBox32.Items68"), resources.GetString("ComboBox32.Items69"), resources.GetString("ComboBox32.Items70"), resources.GetString("ComboBox32.Items71"), resources.GetString("ComboBox32.Items72"), resources.GetString("ComboBox32.Items73"), resources.GetString("ComboBox32.Items74"), resources.GetString("ComboBox32.Items75"), resources.GetString("ComboBox32.Items76"), resources.GetString("ComboBox32.Items77"), resources.GetString("ComboBox32.Items78"), resources.GetString("ComboBox32.Items79"), resources.GetString("ComboBox32.Items80"), resources.GetString("ComboBox32.Items81"), resources.GetString("ComboBox32.Items82"), resources.GetString("ComboBox32.Items83"), resources.GetString("ComboBox32.Items84"), resources.GetString("ComboBox32.Items85"), resources.GetString("ComboBox32.Items86"), resources.GetString("ComboBox32.Items87"), resources.GetString("ComboBox32.Items88"), resources.GetString("ComboBox32.Items89"), resources.GetString("ComboBox32.Items90"), resources.GetString("ComboBox32.Items91"), resources.GetString("ComboBox32.Items92"), resources.GetString("ComboBox32.Items93"), resources.GetString("ComboBox32.Items94"), resources.GetString("ComboBox32.Items95"), resources.GetString("ComboBox32.Items96"), resources.GetString("ComboBox32.Items97"), resources.GetString("ComboBox32.Items98"), resources.GetString("ComboBox32.Items99"), resources.GetString("ComboBox32.Items100"), resources.GetString("ComboBox32.Items101"), resources.GetString("ComboBox32.Items102"), resources.GetString("ComboBox32.Items103"), resources.GetString("ComboBox32.Items104"), resources.GetString("ComboBox32.Items105"), resources.GetString("ComboBox32.Items106"), resources.GetString("ComboBox32.Items107"), resources.GetString("ComboBox32.Items108"), resources.GetString("ComboBox32.Items109"), resources.GetString("ComboBox32.Items110"), resources.GetString("ComboBox32.Items111"), resources.GetString("ComboBox32.Items112"), resources.GetString("ComboBox32.Items113"), resources.GetString("ComboBox32.Items114"), resources.GetString("ComboBox32.Items115"), resources.GetString("ComboBox32.Items116"), resources.GetString("ComboBox32.Items117"), resources.GetString("ComboBox32.Items118"), resources.GetString("ComboBox32.Items119"), resources.GetString("ComboBox32.Items120"), resources.GetString("ComboBox32.Items121"), resources.GetString("ComboBox32.Items122"), resources.GetString("ComboBox32.Items123"), resources.GetString("ComboBox32.Items124"), resources.GetString("ComboBox32.Items125"), resources.GetString("ComboBox32.Items126"), resources.GetString("ComboBox32.Items127"), resources.GetString("ComboBox32.Items128"), resources.GetString("ComboBox32.Items129"), resources.GetString("ComboBox32.Items130"), resources.GetString("ComboBox32.Items131"), resources.GetString("ComboBox32.Items132"), resources.GetString("ComboBox32.Items133"), resources.GetString("ComboBox32.Items134"), resources.GetString("ComboBox32.Items135"), resources.GetString("ComboBox32.Items136"), resources.GetString("ComboBox32.Items137"), resources.GetString("ComboBox32.Items138"), resources.GetString("ComboBox32.Items139"), resources.GetString("ComboBox32.Items140"), resources.GetString("ComboBox32.Items141"), resources.GetString("ComboBox32.Items142"), resources.GetString("ComboBox32.Items143"), resources.GetString("ComboBox32.Items144"), resources.GetString("ComboBox32.Items145"), resources.GetString("ComboBox32.Items146"), resources.GetString("ComboBox32.Items147"), resources.GetString("ComboBox32.Items148"), resources.GetString("ComboBox32.Items149"), resources.GetString("ComboBox32.Items150"), resources.GetString("ComboBox32.Items151"), resources.GetString("ComboBox32.Items152"), resources.GetString("ComboBox32.Items153"), resources.GetString("ComboBox32.Items154"), resources.GetString("ComboBox32.Items155"), resources.GetString("ComboBox32.Items156"), resources.GetString("ComboBox32.Items157"), resources.GetString("ComboBox32.Items158"), resources.GetString("ComboBox32.Items159"), resources.GetString("ComboBox32.Items160"), resources.GetString("ComboBox32.Items161"), resources.GetString("ComboBox32.Items162"), resources.GetString("ComboBox32.Items163"), resources.GetString("ComboBox32.Items164"), resources.GetString("ComboBox32.Items165"), resources.GetString("ComboBox32.Items166"), resources.GetString("ComboBox32.Items167"), resources.GetString("ComboBox32.Items168"), resources.GetString("ComboBox32.Items169"), resources.GetString("ComboBox32.Items170"), resources.GetString("ComboBox32.Items171"), resources.GetString("ComboBox32.Items172"), resources.GetString("ComboBox32.Items173"), resources.GetString("ComboBox32.Items174"), resources.GetString("ComboBox32.Items175"), resources.GetString("ComboBox32.Items176"), resources.GetString("ComboBox32.Items177"), resources.GetString("ComboBox32.Items178"), resources.GetString("ComboBox32.Items179"), resources.GetString("ComboBox32.Items180"), resources.GetString("ComboBox32.Items181"), resources.GetString("ComboBox32.Items182"), resources.GetString("ComboBox32.Items183"), resources.GetString("ComboBox32.Items184"), resources.GetString("ComboBox32.Items185"), resources.GetString("ComboBox32.Items186"), resources.GetString("ComboBox32.Items187"), resources.GetString("ComboBox32.Items188"), resources.GetString("ComboBox32.Items189"), resources.GetString("ComboBox32.Items190"), resources.GetString("ComboBox32.Items191"), resources.GetString("ComboBox32.Items192"), resources.GetString("ComboBox32.Items193"), resources.GetString("ComboBox32.Items194"), resources.GetString("ComboBox32.Items195"), resources.GetString("ComboBox32.Items196")})
        Me.ComboBox32.Name = "ComboBox32"
        '
        'TextBox57
        '
        Me.TextBox57.AccessibleDescription = Nothing
        Me.TextBox57.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox57, "TextBox57")
        Me.TextBox57.BackgroundImage = Nothing
        Me.TextBox57.Font = Nothing
        Me.TextBox57.Name = "TextBox57"
        '
        'ComboBox33
        '
        Me.ComboBox33.AccessibleDescription = Nothing
        Me.ComboBox33.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox33, "ComboBox33")
        Me.ComboBox33.BackgroundImage = Nothing
        Me.ComboBox33.Font = Nothing
        Me.ComboBox33.FormattingEnabled = True
        Me.ComboBox33.Items.AddRange(New Object() {resources.GetString("ComboBox33.Items"), resources.GetString("ComboBox33.Items1"), resources.GetString("ComboBox33.Items2")})
        Me.ComboBox33.Name = "ComboBox33"
        '
        'Label28
        '
        Me.Label28.AccessibleDescription = Nothing
        Me.Label28.AccessibleName = Nothing
        resources.ApplyResources(Me.Label28, "Label28")
        Me.Label28.Font = Nothing
        Me.Label28.Name = "Label28"
        '
        'Label29
        '
        Me.Label29.AccessibleDescription = Nothing
        Me.Label29.AccessibleName = Nothing
        resources.ApplyResources(Me.Label29, "Label29")
        Me.Label29.Font = Nothing
        Me.Label29.Name = "Label29"
        '
        'TextBox58
        '
        Me.TextBox58.AccessibleDescription = Nothing
        Me.TextBox58.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox58, "TextBox58")
        Me.TextBox58.BackgroundImage = Nothing
        Me.TextBox58.Font = Nothing
        Me.TextBox58.Name = "TextBox58"
        '
        'ComboBox34
        '
        Me.ComboBox34.AccessibleDescription = Nothing
        Me.ComboBox34.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox34, "ComboBox34")
        Me.ComboBox34.BackgroundImage = Nothing
        Me.ComboBox34.Cursor = System.Windows.Forms.Cursors.Default
        Me.ComboBox34.Font = Nothing
        Me.ComboBox34.FormattingEnabled = True
        Me.ComboBox34.Items.AddRange(New Object() {resources.GetString("ComboBox34.Items"), resources.GetString("ComboBox34.Items1"), resources.GetString("ComboBox34.Items2"), resources.GetString("ComboBox34.Items3"), resources.GetString("ComboBox34.Items4"), resources.GetString("ComboBox34.Items5"), resources.GetString("ComboBox34.Items6"), resources.GetString("ComboBox34.Items7"), resources.GetString("ComboBox34.Items8"), resources.GetString("ComboBox34.Items9"), resources.GetString("ComboBox34.Items10"), resources.GetString("ComboBox34.Items11"), resources.GetString("ComboBox34.Items12"), resources.GetString("ComboBox34.Items13"), resources.GetString("ComboBox34.Items14"), resources.GetString("ComboBox34.Items15"), resources.GetString("ComboBox34.Items16"), resources.GetString("ComboBox34.Items17"), resources.GetString("ComboBox34.Items18"), resources.GetString("ComboBox34.Items19"), resources.GetString("ComboBox34.Items20"), resources.GetString("ComboBox34.Items21"), resources.GetString("ComboBox34.Items22"), resources.GetString("ComboBox34.Items23"), resources.GetString("ComboBox34.Items24"), resources.GetString("ComboBox34.Items25"), resources.GetString("ComboBox34.Items26"), resources.GetString("ComboBox34.Items27"), resources.GetString("ComboBox34.Items28"), resources.GetString("ComboBox34.Items29"), resources.GetString("ComboBox34.Items30"), resources.GetString("ComboBox34.Items31"), resources.GetString("ComboBox34.Items32"), resources.GetString("ComboBox34.Items33"), resources.GetString("ComboBox34.Items34"), resources.GetString("ComboBox34.Items35"), resources.GetString("ComboBox34.Items36"), resources.GetString("ComboBox34.Items37"), resources.GetString("ComboBox34.Items38"), resources.GetString("ComboBox34.Items39"), resources.GetString("ComboBox34.Items40"), resources.GetString("ComboBox34.Items41"), resources.GetString("ComboBox34.Items42"), resources.GetString("ComboBox34.Items43"), resources.GetString("ComboBox34.Items44"), resources.GetString("ComboBox34.Items45"), resources.GetString("ComboBox34.Items46"), resources.GetString("ComboBox34.Items47"), resources.GetString("ComboBox34.Items48"), resources.GetString("ComboBox34.Items49"), resources.GetString("ComboBox34.Items50"), resources.GetString("ComboBox34.Items51"), resources.GetString("ComboBox34.Items52"), resources.GetString("ComboBox34.Items53"), resources.GetString("ComboBox34.Items54"), resources.GetString("ComboBox34.Items55"), resources.GetString("ComboBox34.Items56"), resources.GetString("ComboBox34.Items57"), resources.GetString("ComboBox34.Items58"), resources.GetString("ComboBox34.Items59"), resources.GetString("ComboBox34.Items60"), resources.GetString("ComboBox34.Items61"), resources.GetString("ComboBox34.Items62"), resources.GetString("ComboBox34.Items63"), resources.GetString("ComboBox34.Items64"), resources.GetString("ComboBox34.Items65"), resources.GetString("ComboBox34.Items66"), resources.GetString("ComboBox34.Items67"), resources.GetString("ComboBox34.Items68"), resources.GetString("ComboBox34.Items69"), resources.GetString("ComboBox34.Items70"), resources.GetString("ComboBox34.Items71"), resources.GetString("ComboBox34.Items72"), resources.GetString("ComboBox34.Items73"), resources.GetString("ComboBox34.Items74"), resources.GetString("ComboBox34.Items75"), resources.GetString("ComboBox34.Items76"), resources.GetString("ComboBox34.Items77"), resources.GetString("ComboBox34.Items78"), resources.GetString("ComboBox34.Items79"), resources.GetString("ComboBox34.Items80"), resources.GetString("ComboBox34.Items81"), resources.GetString("ComboBox34.Items82"), resources.GetString("ComboBox34.Items83"), resources.GetString("ComboBox34.Items84"), resources.GetString("ComboBox34.Items85"), resources.GetString("ComboBox34.Items86"), resources.GetString("ComboBox34.Items87"), resources.GetString("ComboBox34.Items88"), resources.GetString("ComboBox34.Items89"), resources.GetString("ComboBox34.Items90"), resources.GetString("ComboBox34.Items91"), resources.GetString("ComboBox34.Items92"), resources.GetString("ComboBox34.Items93"), resources.GetString("ComboBox34.Items94"), resources.GetString("ComboBox34.Items95"), resources.GetString("ComboBox34.Items96"), resources.GetString("ComboBox34.Items97"), resources.GetString("ComboBox34.Items98"), resources.GetString("ComboBox34.Items99"), resources.GetString("ComboBox34.Items100"), resources.GetString("ComboBox34.Items101"), resources.GetString("ComboBox34.Items102"), resources.GetString("ComboBox34.Items103"), resources.GetString("ComboBox34.Items104"), resources.GetString("ComboBox34.Items105"), resources.GetString("ComboBox34.Items106"), resources.GetString("ComboBox34.Items107"), resources.GetString("ComboBox34.Items108"), resources.GetString("ComboBox34.Items109"), resources.GetString("ComboBox34.Items110"), resources.GetString("ComboBox34.Items111"), resources.GetString("ComboBox34.Items112"), resources.GetString("ComboBox34.Items113"), resources.GetString("ComboBox34.Items114"), resources.GetString("ComboBox34.Items115"), resources.GetString("ComboBox34.Items116"), resources.GetString("ComboBox34.Items117"), resources.GetString("ComboBox34.Items118"), resources.GetString("ComboBox34.Items119"), resources.GetString("ComboBox34.Items120"), resources.GetString("ComboBox34.Items121"), resources.GetString("ComboBox34.Items122"), resources.GetString("ComboBox34.Items123"), resources.GetString("ComboBox34.Items124"), resources.GetString("ComboBox34.Items125"), resources.GetString("ComboBox34.Items126"), resources.GetString("ComboBox34.Items127"), resources.GetString("ComboBox34.Items128"), resources.GetString("ComboBox34.Items129"), resources.GetString("ComboBox34.Items130"), resources.GetString("ComboBox34.Items131"), resources.GetString("ComboBox34.Items132"), resources.GetString("ComboBox34.Items133"), resources.GetString("ComboBox34.Items134"), resources.GetString("ComboBox34.Items135"), resources.GetString("ComboBox34.Items136"), resources.GetString("ComboBox34.Items137"), resources.GetString("ComboBox34.Items138"), resources.GetString("ComboBox34.Items139"), resources.GetString("ComboBox34.Items140"), resources.GetString("ComboBox34.Items141"), resources.GetString("ComboBox34.Items142"), resources.GetString("ComboBox34.Items143"), resources.GetString("ComboBox34.Items144"), resources.GetString("ComboBox34.Items145"), resources.GetString("ComboBox34.Items146"), resources.GetString("ComboBox34.Items147"), resources.GetString("ComboBox34.Items148"), resources.GetString("ComboBox34.Items149"), resources.GetString("ComboBox34.Items150"), resources.GetString("ComboBox34.Items151"), resources.GetString("ComboBox34.Items152"), resources.GetString("ComboBox34.Items153"), resources.GetString("ComboBox34.Items154"), resources.GetString("ComboBox34.Items155"), resources.GetString("ComboBox34.Items156"), resources.GetString("ComboBox34.Items157"), resources.GetString("ComboBox34.Items158"), resources.GetString("ComboBox34.Items159"), resources.GetString("ComboBox34.Items160"), resources.GetString("ComboBox34.Items161"), resources.GetString("ComboBox34.Items162"), resources.GetString("ComboBox34.Items163"), resources.GetString("ComboBox34.Items164"), resources.GetString("ComboBox34.Items165"), resources.GetString("ComboBox34.Items166"), resources.GetString("ComboBox34.Items167"), resources.GetString("ComboBox34.Items168"), resources.GetString("ComboBox34.Items169"), resources.GetString("ComboBox34.Items170"), resources.GetString("ComboBox34.Items171"), resources.GetString("ComboBox34.Items172"), resources.GetString("ComboBox34.Items173"), resources.GetString("ComboBox34.Items174"), resources.GetString("ComboBox34.Items175"), resources.GetString("ComboBox34.Items176"), resources.GetString("ComboBox34.Items177"), resources.GetString("ComboBox34.Items178"), resources.GetString("ComboBox34.Items179"), resources.GetString("ComboBox34.Items180"), resources.GetString("ComboBox34.Items181"), resources.GetString("ComboBox34.Items182"), resources.GetString("ComboBox34.Items183"), resources.GetString("ComboBox34.Items184"), resources.GetString("ComboBox34.Items185"), resources.GetString("ComboBox34.Items186"), resources.GetString("ComboBox34.Items187"), resources.GetString("ComboBox34.Items188"), resources.GetString("ComboBox34.Items189"), resources.GetString("ComboBox34.Items190"), resources.GetString("ComboBox34.Items191"), resources.GetString("ComboBox34.Items192"), resources.GetString("ComboBox34.Items193"), resources.GetString("ComboBox34.Items194"), resources.GetString("ComboBox34.Items195"), resources.GetString("ComboBox34.Items196")})
        Me.ComboBox34.Name = "ComboBox34"
        '
        'TextBox59
        '
        Me.TextBox59.AccessibleDescription = Nothing
        Me.TextBox59.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox59, "TextBox59")
        Me.TextBox59.BackgroundImage = Nothing
        Me.TextBox59.Font = Nothing
        Me.TextBox59.Name = "TextBox59"
        '
        'TextBox60
        '
        Me.TextBox60.AccessibleDescription = Nothing
        Me.TextBox60.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox60, "TextBox60")
        Me.TextBox60.BackgroundImage = Nothing
        Me.TextBox60.Font = Nothing
        Me.TextBox60.Name = "TextBox60"
        '
        'ComboBox35
        '
        Me.ComboBox35.AccessibleDescription = Nothing
        Me.ComboBox35.AccessibleName = Nothing
        resources.ApplyResources(Me.ComboBox35, "ComboBox35")
        Me.ComboBox35.BackgroundImage = Nothing
        Me.ComboBox35.Font = Nothing
        Me.ComboBox35.FormattingEnabled = True
        Me.ComboBox35.Items.AddRange(New Object() {resources.GetString("ComboBox35.Items"), resources.GetString("ComboBox35.Items1"), resources.GetString("ComboBox35.Items2")})
        Me.ComboBox35.Name = "ComboBox35"
        '
        'TextBox61
        '
        Me.TextBox61.AccessibleDescription = Nothing
        Me.TextBox61.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox61, "TextBox61")
        Me.TextBox61.BackgroundImage = Nothing
        Me.TextBox61.Font = Nothing
        Me.TextBox61.Name = "TextBox61"
        '
        'TextBox62
        '
        Me.TextBox62.AccessibleDescription = Nothing
        Me.TextBox62.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox62, "TextBox62")
        Me.TextBox62.BackgroundImage = Nothing
        Me.TextBox62.Font = Nothing
        Me.TextBox62.Name = "TextBox62"
        '
        'TextBox63
        '
        Me.TextBox63.AccessibleDescription = Nothing
        Me.TextBox63.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox63, "TextBox63")
        Me.TextBox63.BackgroundImage = Nothing
        Me.TextBox63.Font = Nothing
        Me.TextBox63.Name = "TextBox63"
        '
        'TextBox64
        '
        Me.TextBox64.AccessibleDescription = Nothing
        Me.TextBox64.AccessibleName = Nothing
        resources.ApplyResources(Me.TextBox64, "TextBox64")
        Me.TextBox64.BackgroundImage = Nothing
        Me.TextBox64.Font = Nothing
        Me.TextBox64.Name = "TextBox64"
        '
        'Label30
        '
        Me.Label30.AccessibleDescription = Nothing
        Me.Label30.AccessibleName = Nothing
        resources.ApplyResources(Me.Label30, "Label30")
        Me.Label30.Font = Nothing
        Me.Label30.Name = "Label30"
        '
        'RadioButton3
        '
        Me.RadioButton3.AccessibleDescription = Nothing
        Me.RadioButton3.AccessibleName = Nothing
        resources.ApplyResources(Me.RadioButton3, "RadioButton3")
        Me.RadioButton3.BackgroundImage = Nothing
        Me.RadioButton3.Font = Nothing
        Me.RadioButton3.Name = "RadioButton3"
        Me.RadioButton3.TabStop = True
        Me.RadioButton3.UseVisualStyleBackColor = True
        '
        'RadioButton4
        '
        Me.RadioButton4.AccessibleDescription = Nothing
        Me.RadioButton4.AccessibleName = Nothing
        resources.ApplyResources(Me.RadioButton4, "RadioButton4")
        Me.RadioButton4.BackgroundImage = Nothing
        Me.RadioButton4.Font = Nothing
        Me.RadioButton4.Name = "RadioButton4"
        Me.RadioButton4.TabStop = True
        Me.RadioButton4.UseVisualStyleBackColor = True
        '
        'Label31
        '
        Me.Label31.AccessibleDescription = Nothing
        Me.Label31.AccessibleName = Nothing
        resources.ApplyResources(Me.Label31, "Label31")
        Me.Label31.Font = Nothing
        Me.Label31.Name = "Label31"
        '
        'btnEnviar
        '
        Me.btnEnviar.AccessibleDescription = Nothing
        Me.btnEnviar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnEnviar, "btnEnviar")
        Me.btnEnviar.BackgroundImage = Nothing
        Me.btnEnviar.Name = "btnEnviar"
        Me.btnEnviar.UseVisualStyleBackColor = True
        '
        'btnLimpiar
        '
        Me.btnLimpiar.AccessibleDescription = Nothing
        Me.btnLimpiar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnLimpiar, "btnLimpiar")
        Me.btnLimpiar.BackgroundImage = Nothing
        Me.btnLimpiar.Font = Nothing
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.UseVisualStyleBackColor = True
        '
        'grpDatosEmpresa
        '
        Me.grpDatosEmpresa.AccessibleDescription = Nothing
        Me.grpDatosEmpresa.AccessibleName = Nothing
        resources.ApplyResources(Me.grpDatosEmpresa, "grpDatosEmpresa")
        Me.grpDatosEmpresa.BackgroundImage = Nothing
        Me.grpDatosEmpresa.Controls.Add(Me.grpContacto)
        Me.grpDatosEmpresa.Controls.Add(Me.GroupBox2)
        Me.grpDatosEmpresa.Controls.Add(Me.lblDepartamento)
        Me.grpDatosEmpresa.Controls.Add(Me.txtDepartamentoEmpresa)
        Me.grpDatosEmpresa.Controls.Add(Me.lblCiudad)
        Me.grpDatosEmpresa.Controls.Add(Me.txtCiudadEmpresa)
        Me.grpDatosEmpresa.Controls.Add(Me.cboPaisResidenciaEmpresa)
        Me.grpDatosEmpresa.Controls.Add(Me.lblPaisResidencia)
        Me.grpDatosEmpresa.Controls.Add(Me.cboPaisOrigenCapital)
        Me.grpDatosEmpresa.Controls.Add(Me.txtRUT)
        Me.grpDatosEmpresa.Controls.Add(Me.lblPaisOrigen)
        Me.grpDatosEmpresa.Controls.Add(Me.cboTipoSociedad)
        Me.grpDatosEmpresa.Controls.Add(Me.lblRUT)
        Me.grpDatosEmpresa.Controls.Add(Me.lblTipoSociedad)
        Me.grpDatosEmpresa.Controls.Add(Me.lblRazonSocial)
        Me.grpDatosEmpresa.Controls.Add(Me.txtRazonSocial)
        Me.grpDatosEmpresa.Font = Nothing
        Me.grpDatosEmpresa.Name = "grpDatosEmpresa"
        Me.grpDatosEmpresa.TabStop = False
        '
        'grpContacto
        '
        Me.grpContacto.AccessibleDescription = Nothing
        Me.grpContacto.AccessibleName = Nothing
        resources.ApplyResources(Me.grpContacto, "grpContacto")
        Me.grpContacto.BackgroundImage = Nothing
        Me.grpContacto.Controls.Add(Me.lblWeb)
        Me.grpContacto.Controls.Add(Me.txtContactoSitioWeb)
        Me.grpContacto.Controls.Add(Me.lblEmail)
        Me.grpContacto.Controls.Add(Me.txtContactoEmail)
        Me.grpContacto.Controls.Add(Me.lblTelefonos)
        Me.grpContacto.Controls.Add(Me.txtContactoNumerosTelefono)
        Me.grpContacto.Font = Nothing
        Me.grpContacto.Name = "grpContacto"
        Me.grpContacto.TabStop = False
        '
        'lblWeb
        '
        Me.lblWeb.AccessibleDescription = Nothing
        Me.lblWeb.AccessibleName = Nothing
        resources.ApplyResources(Me.lblWeb, "lblWeb")
        Me.lblWeb.Font = Nothing
        Me.lblWeb.Name = "lblWeb"
        '
        'txtContactoSitioWeb
        '
        Me.txtContactoSitioWeb.AccessibleDescription = Nothing
        Me.txtContactoSitioWeb.AccessibleName = Nothing
        resources.ApplyResources(Me.txtContactoSitioWeb, "txtContactoSitioWeb")
        Me.txtContactoSitioWeb.BackgroundImage = Nothing
        Me.txtContactoSitioWeb.Font = Nothing
        Me.txtContactoSitioWeb.Name = "txtContactoSitioWeb"
        '
        'lblEmail
        '
        Me.lblEmail.AccessibleDescription = Nothing
        Me.lblEmail.AccessibleName = Nothing
        resources.ApplyResources(Me.lblEmail, "lblEmail")
        Me.lblEmail.Font = Nothing
        Me.lblEmail.Name = "lblEmail"
        '
        'txtContactoEmail
        '
        Me.txtContactoEmail.AccessibleDescription = Nothing
        Me.txtContactoEmail.AccessibleName = Nothing
        resources.ApplyResources(Me.txtContactoEmail, "txtContactoEmail")
        Me.txtContactoEmail.BackgroundImage = Nothing
        Me.txtContactoEmail.Font = Nothing
        Me.txtContactoEmail.Name = "txtContactoEmail"
        '
        'lblTelefonos
        '
        Me.lblTelefonos.AccessibleDescription = Nothing
        Me.lblTelefonos.AccessibleName = Nothing
        resources.ApplyResources(Me.lblTelefonos, "lblTelefonos")
        Me.lblTelefonos.Font = Nothing
        Me.lblTelefonos.Name = "lblTelefonos"
        '
        'txtContactoNumerosTelefono
        '
        Me.txtContactoNumerosTelefono.AccessibleDescription = Nothing
        Me.txtContactoNumerosTelefono.AccessibleName = Nothing
        resources.ApplyResources(Me.txtContactoNumerosTelefono, "txtContactoNumerosTelefono")
        Me.txtContactoNumerosTelefono.BackgroundImage = Nothing
        Me.txtContactoNumerosTelefono.Font = Nothing
        Me.txtContactoNumerosTelefono.Name = "txtContactoNumerosTelefono"
        '
        'GroupBox2
        '
        Me.GroupBox2.AccessibleDescription = Nothing
        Me.GroupBox2.AccessibleName = Nothing
        resources.ApplyResources(Me.GroupBox2, "GroupBox2")
        Me.GroupBox2.BackgroundImage = Nothing
        Me.GroupBox2.Controls.Add(Me.lblCodPostal)
        Me.GroupBox2.Controls.Add(Me.txtDomicilioEmpresaCodPostal)
        Me.GroupBox2.Controls.Add(Me.lblAPTDomicilio)
        Me.GroupBox2.Controls.Add(Me.txtDomicilioEmpresaApartamento)
        Me.GroupBox2.Controls.Add(Me.lblBlockDomicilio)
        Me.GroupBox2.Controls.Add(Me.txtDomicilioEmpresaBlock)
        Me.GroupBox2.Controls.Add(Me.lblNroDomicilio)
        Me.GroupBox2.Controls.Add(Me.txtDomicilioEmpresaNumero)
        Me.GroupBox2.Controls.Add(Me.lblCalleDomicilio)
        Me.GroupBox2.Controls.Add(Me.txtDomicilioEmpresaCalle)
        Me.GroupBox2.Font = Nothing
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.TabStop = False
        '
        'lblCodPostal
        '
        Me.lblCodPostal.AccessibleDescription = Nothing
        Me.lblCodPostal.AccessibleName = Nothing
        resources.ApplyResources(Me.lblCodPostal, "lblCodPostal")
        Me.lblCodPostal.Font = Nothing
        Me.lblCodPostal.Name = "lblCodPostal"
        '
        'txtDomicilioEmpresaCodPostal
        '
        Me.txtDomicilioEmpresaCodPostal.AccessibleDescription = Nothing
        Me.txtDomicilioEmpresaCodPostal.AccessibleName = Nothing
        resources.ApplyResources(Me.txtDomicilioEmpresaCodPostal, "txtDomicilioEmpresaCodPostal")
        Me.txtDomicilioEmpresaCodPostal.BackgroundImage = Nothing
        Me.txtDomicilioEmpresaCodPostal.Font = Nothing
        Me.txtDomicilioEmpresaCodPostal.Name = "txtDomicilioEmpresaCodPostal"
        '
        'lblAPTDomicilio
        '
        Me.lblAPTDomicilio.AccessibleDescription = Nothing
        Me.lblAPTDomicilio.AccessibleName = Nothing
        resources.ApplyResources(Me.lblAPTDomicilio, "lblAPTDomicilio")
        Me.lblAPTDomicilio.Font = Nothing
        Me.lblAPTDomicilio.Name = "lblAPTDomicilio"
        '
        'txtDomicilioEmpresaApartamento
        '
        Me.txtDomicilioEmpresaApartamento.AccessibleDescription = Nothing
        Me.txtDomicilioEmpresaApartamento.AccessibleName = Nothing
        resources.ApplyResources(Me.txtDomicilioEmpresaApartamento, "txtDomicilioEmpresaApartamento")
        Me.txtDomicilioEmpresaApartamento.BackgroundImage = Nothing
        Me.txtDomicilioEmpresaApartamento.Font = Nothing
        Me.txtDomicilioEmpresaApartamento.Name = "txtDomicilioEmpresaApartamento"
        '
        'lblBlockDomicilio
        '
        Me.lblBlockDomicilio.AccessibleDescription = Nothing
        Me.lblBlockDomicilio.AccessibleName = Nothing
        resources.ApplyResources(Me.lblBlockDomicilio, "lblBlockDomicilio")
        Me.lblBlockDomicilio.Font = Nothing
        Me.lblBlockDomicilio.Name = "lblBlockDomicilio"
        '
        'txtDomicilioEmpresaBlock
        '
        Me.txtDomicilioEmpresaBlock.AccessibleDescription = Nothing
        Me.txtDomicilioEmpresaBlock.AccessibleName = Nothing
        resources.ApplyResources(Me.txtDomicilioEmpresaBlock, "txtDomicilioEmpresaBlock")
        Me.txtDomicilioEmpresaBlock.BackgroundImage = Nothing
        Me.txtDomicilioEmpresaBlock.Font = Nothing
        Me.txtDomicilioEmpresaBlock.Name = "txtDomicilioEmpresaBlock"
        '
        'lblNroDomicilio
        '
        Me.lblNroDomicilio.AccessibleDescription = Nothing
        Me.lblNroDomicilio.AccessibleName = Nothing
        resources.ApplyResources(Me.lblNroDomicilio, "lblNroDomicilio")
        Me.lblNroDomicilio.Font = Nothing
        Me.lblNroDomicilio.Name = "lblNroDomicilio"
        '
        'txtDomicilioEmpresaNumero
        '
        Me.txtDomicilioEmpresaNumero.AccessibleDescription = Nothing
        Me.txtDomicilioEmpresaNumero.AccessibleName = Nothing
        resources.ApplyResources(Me.txtDomicilioEmpresaNumero, "txtDomicilioEmpresaNumero")
        Me.txtDomicilioEmpresaNumero.BackgroundImage = Nothing
        Me.txtDomicilioEmpresaNumero.Font = Nothing
        Me.txtDomicilioEmpresaNumero.Name = "txtDomicilioEmpresaNumero"
        '
        'lblCalleDomicilio
        '
        Me.lblCalleDomicilio.AccessibleDescription = Nothing
        Me.lblCalleDomicilio.AccessibleName = Nothing
        resources.ApplyResources(Me.lblCalleDomicilio, "lblCalleDomicilio")
        Me.lblCalleDomicilio.Font = Nothing
        Me.lblCalleDomicilio.Name = "lblCalleDomicilio"
        '
        'txtDomicilioEmpresaCalle
        '
        Me.txtDomicilioEmpresaCalle.AccessibleDescription = Nothing
        Me.txtDomicilioEmpresaCalle.AccessibleName = Nothing
        resources.ApplyResources(Me.txtDomicilioEmpresaCalle, "txtDomicilioEmpresaCalle")
        Me.txtDomicilioEmpresaCalle.BackgroundImage = Nothing
        Me.txtDomicilioEmpresaCalle.Font = Nothing
        Me.txtDomicilioEmpresaCalle.Name = "txtDomicilioEmpresaCalle"
        '
        'lblDepartamento
        '
        Me.lblDepartamento.AccessibleDescription = Nothing
        Me.lblDepartamento.AccessibleName = Nothing
        resources.ApplyResources(Me.lblDepartamento, "lblDepartamento")
        Me.lblDepartamento.Font = Nothing
        Me.lblDepartamento.Name = "lblDepartamento"
        '
        'txtDepartamentoEmpresa
        '
        Me.txtDepartamentoEmpresa.AccessibleDescription = Nothing
        Me.txtDepartamentoEmpresa.AccessibleName = Nothing
        resources.ApplyResources(Me.txtDepartamentoEmpresa, "txtDepartamentoEmpresa")
        Me.txtDepartamentoEmpresa.BackgroundImage = Nothing
        Me.txtDepartamentoEmpresa.Font = Nothing
        Me.txtDepartamentoEmpresa.Name = "txtDepartamentoEmpresa"
        '
        'lblCiudad
        '
        Me.lblCiudad.AccessibleDescription = Nothing
        Me.lblCiudad.AccessibleName = Nothing
        resources.ApplyResources(Me.lblCiudad, "lblCiudad")
        Me.lblCiudad.Font = Nothing
        Me.lblCiudad.Name = "lblCiudad"
        '
        'txtCiudadEmpresa
        '
        Me.txtCiudadEmpresa.AccessibleDescription = Nothing
        Me.txtCiudadEmpresa.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCiudadEmpresa, "txtCiudadEmpresa")
        Me.txtCiudadEmpresa.BackgroundImage = Nothing
        Me.txtCiudadEmpresa.Font = Nothing
        Me.txtCiudadEmpresa.Name = "txtCiudadEmpresa"
        '
        'cboPaisResidenciaEmpresa
        '
        Me.cboPaisResidenciaEmpresa.AccessibleDescription = Nothing
        Me.cboPaisResidenciaEmpresa.AccessibleName = Nothing
        resources.ApplyResources(Me.cboPaisResidenciaEmpresa, "cboPaisResidenciaEmpresa")
        Me.cboPaisResidenciaEmpresa.BackgroundImage = Nothing
        Me.cboPaisResidenciaEmpresa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPaisResidenciaEmpresa.Font = Nothing
        Me.cboPaisResidenciaEmpresa.FormattingEnabled = True
        Me.cboPaisResidenciaEmpresa.Items.AddRange(New Object() {resources.GetString("cboPaisResidenciaEmpresa.Items"), resources.GetString("cboPaisResidenciaEmpresa.Items1"), resources.GetString("cboPaisResidenciaEmpresa.Items2"), resources.GetString("cboPaisResidenciaEmpresa.Items3"), resources.GetString("cboPaisResidenciaEmpresa.Items4"), resources.GetString("cboPaisResidenciaEmpresa.Items5"), resources.GetString("cboPaisResidenciaEmpresa.Items6"), resources.GetString("cboPaisResidenciaEmpresa.Items7"), resources.GetString("cboPaisResidenciaEmpresa.Items8"), resources.GetString("cboPaisResidenciaEmpresa.Items9"), resources.GetString("cboPaisResidenciaEmpresa.Items10"), resources.GetString("cboPaisResidenciaEmpresa.Items11"), resources.GetString("cboPaisResidenciaEmpresa.Items12"), resources.GetString("cboPaisResidenciaEmpresa.Items13"), resources.GetString("cboPaisResidenciaEmpresa.Items14"), resources.GetString("cboPaisResidenciaEmpresa.Items15"), resources.GetString("cboPaisResidenciaEmpresa.Items16"), resources.GetString("cboPaisResidenciaEmpresa.Items17"), resources.GetString("cboPaisResidenciaEmpresa.Items18"), resources.GetString("cboPaisResidenciaEmpresa.Items19"), resources.GetString("cboPaisResidenciaEmpresa.Items20"), resources.GetString("cboPaisResidenciaEmpresa.Items21"), resources.GetString("cboPaisResidenciaEmpresa.Items22"), resources.GetString("cboPaisResidenciaEmpresa.Items23"), resources.GetString("cboPaisResidenciaEmpresa.Items24"), resources.GetString("cboPaisResidenciaEmpresa.Items25"), resources.GetString("cboPaisResidenciaEmpresa.Items26"), resources.GetString("cboPaisResidenciaEmpresa.Items27"), resources.GetString("cboPaisResidenciaEmpresa.Items28"), resources.GetString("cboPaisResidenciaEmpresa.Items29"), resources.GetString("cboPaisResidenciaEmpresa.Items30"), resources.GetString("cboPaisResidenciaEmpresa.Items31"), resources.GetString("cboPaisResidenciaEmpresa.Items32"), resources.GetString("cboPaisResidenciaEmpresa.Items33"), resources.GetString("cboPaisResidenciaEmpresa.Items34"), resources.GetString("cboPaisResidenciaEmpresa.Items35"), resources.GetString("cboPaisResidenciaEmpresa.Items36"), resources.GetString("cboPaisResidenciaEmpresa.Items37"), resources.GetString("cboPaisResidenciaEmpresa.Items38"), resources.GetString("cboPaisResidenciaEmpresa.Items39"), resources.GetString("cboPaisResidenciaEmpresa.Items40"), resources.GetString("cboPaisResidenciaEmpresa.Items41"), resources.GetString("cboPaisResidenciaEmpresa.Items42"), resources.GetString("cboPaisResidenciaEmpresa.Items43"), resources.GetString("cboPaisResidenciaEmpresa.Items44"), resources.GetString("cboPaisResidenciaEmpresa.Items45"), resources.GetString("cboPaisResidenciaEmpresa.Items46"), resources.GetString("cboPaisResidenciaEmpresa.Items47"), resources.GetString("cboPaisResidenciaEmpresa.Items48"), resources.GetString("cboPaisResidenciaEmpresa.Items49"), resources.GetString("cboPaisResidenciaEmpresa.Items50"), resources.GetString("cboPaisResidenciaEmpresa.Items51"), resources.GetString("cboPaisResidenciaEmpresa.Items52"), resources.GetString("cboPaisResidenciaEmpresa.Items53"), resources.GetString("cboPaisResidenciaEmpresa.Items54"), resources.GetString("cboPaisResidenciaEmpresa.Items55"), resources.GetString("cboPaisResidenciaEmpresa.Items56"), resources.GetString("cboPaisResidenciaEmpresa.Items57"), resources.GetString("cboPaisResidenciaEmpresa.Items58"), resources.GetString("cboPaisResidenciaEmpresa.Items59"), resources.GetString("cboPaisResidenciaEmpresa.Items60"), resources.GetString("cboPaisResidenciaEmpresa.Items61"), resources.GetString("cboPaisResidenciaEmpresa.Items62"), resources.GetString("cboPaisResidenciaEmpresa.Items63"), resources.GetString("cboPaisResidenciaEmpresa.Items64"), resources.GetString("cboPaisResidenciaEmpresa.Items65"), resources.GetString("cboPaisResidenciaEmpresa.Items66"), resources.GetString("cboPaisResidenciaEmpresa.Items67"), resources.GetString("cboPaisResidenciaEmpresa.Items68"), resources.GetString("cboPaisResidenciaEmpresa.Items69"), resources.GetString("cboPaisResidenciaEmpresa.Items70"), resources.GetString("cboPaisResidenciaEmpresa.Items71"), resources.GetString("cboPaisResidenciaEmpresa.Items72"), resources.GetString("cboPaisResidenciaEmpresa.Items73"), resources.GetString("cboPaisResidenciaEmpresa.Items74"), resources.GetString("cboPaisResidenciaEmpresa.Items75"), resources.GetString("cboPaisResidenciaEmpresa.Items76"), resources.GetString("cboPaisResidenciaEmpresa.Items77"), resources.GetString("cboPaisResidenciaEmpresa.Items78"), resources.GetString("cboPaisResidenciaEmpresa.Items79"), resources.GetString("cboPaisResidenciaEmpresa.Items80"), resources.GetString("cboPaisResidenciaEmpresa.Items81"), resources.GetString("cboPaisResidenciaEmpresa.Items82"), resources.GetString("cboPaisResidenciaEmpresa.Items83"), resources.GetString("cboPaisResidenciaEmpresa.Items84"), resources.GetString("cboPaisResidenciaEmpresa.Items85"), resources.GetString("cboPaisResidenciaEmpresa.Items86"), resources.GetString("cboPaisResidenciaEmpresa.Items87"), resources.GetString("cboPaisResidenciaEmpresa.Items88"), resources.GetString("cboPaisResidenciaEmpresa.Items89"), resources.GetString("cboPaisResidenciaEmpresa.Items90"), resources.GetString("cboPaisResidenciaEmpresa.Items91"), resources.GetString("cboPaisResidenciaEmpresa.Items92"), resources.GetString("cboPaisResidenciaEmpresa.Items93"), resources.GetString("cboPaisResidenciaEmpresa.Items94"), resources.GetString("cboPaisResidenciaEmpresa.Items95"), resources.GetString("cboPaisResidenciaEmpresa.Items96"), resources.GetString("cboPaisResidenciaEmpresa.Items97"), resources.GetString("cboPaisResidenciaEmpresa.Items98"), resources.GetString("cboPaisResidenciaEmpresa.Items99"), resources.GetString("cboPaisResidenciaEmpresa.Items100"), resources.GetString("cboPaisResidenciaEmpresa.Items101"), resources.GetString("cboPaisResidenciaEmpresa.Items102"), resources.GetString("cboPaisResidenciaEmpresa.Items103"), resources.GetString("cboPaisResidenciaEmpresa.Items104"), resources.GetString("cboPaisResidenciaEmpresa.Items105"), resources.GetString("cboPaisResidenciaEmpresa.Items106"), resources.GetString("cboPaisResidenciaEmpresa.Items107"), resources.GetString("cboPaisResidenciaEmpresa.Items108"), resources.GetString("cboPaisResidenciaEmpresa.Items109"), resources.GetString("cboPaisResidenciaEmpresa.Items110"), resources.GetString("cboPaisResidenciaEmpresa.Items111"), resources.GetString("cboPaisResidenciaEmpresa.Items112"), resources.GetString("cboPaisResidenciaEmpresa.Items113"), resources.GetString("cboPaisResidenciaEmpresa.Items114"), resources.GetString("cboPaisResidenciaEmpresa.Items115"), resources.GetString("cboPaisResidenciaEmpresa.Items116"), resources.GetString("cboPaisResidenciaEmpresa.Items117"), resources.GetString("cboPaisResidenciaEmpresa.Items118"), resources.GetString("cboPaisResidenciaEmpresa.Items119"), resources.GetString("cboPaisResidenciaEmpresa.Items120"), resources.GetString("cboPaisResidenciaEmpresa.Items121"), resources.GetString("cboPaisResidenciaEmpresa.Items122"), resources.GetString("cboPaisResidenciaEmpresa.Items123"), resources.GetString("cboPaisResidenciaEmpresa.Items124"), resources.GetString("cboPaisResidenciaEmpresa.Items125"), resources.GetString("cboPaisResidenciaEmpresa.Items126"), resources.GetString("cboPaisResidenciaEmpresa.Items127"), resources.GetString("cboPaisResidenciaEmpresa.Items128"), resources.GetString("cboPaisResidenciaEmpresa.Items129"), resources.GetString("cboPaisResidenciaEmpresa.Items130"), resources.GetString("cboPaisResidenciaEmpresa.Items131"), resources.GetString("cboPaisResidenciaEmpresa.Items132"), resources.GetString("cboPaisResidenciaEmpresa.Items133"), resources.GetString("cboPaisResidenciaEmpresa.Items134"), resources.GetString("cboPaisResidenciaEmpresa.Items135"), resources.GetString("cboPaisResidenciaEmpresa.Items136"), resources.GetString("cboPaisResidenciaEmpresa.Items137"), resources.GetString("cboPaisResidenciaEmpresa.Items138"), resources.GetString("cboPaisResidenciaEmpresa.Items139"), resources.GetString("cboPaisResidenciaEmpresa.Items140"), resources.GetString("cboPaisResidenciaEmpresa.Items141"), resources.GetString("cboPaisResidenciaEmpresa.Items142"), resources.GetString("cboPaisResidenciaEmpresa.Items143"), resources.GetString("cboPaisResidenciaEmpresa.Items144"), resources.GetString("cboPaisResidenciaEmpresa.Items145"), resources.GetString("cboPaisResidenciaEmpresa.Items146"), resources.GetString("cboPaisResidenciaEmpresa.Items147"), resources.GetString("cboPaisResidenciaEmpresa.Items148"), resources.GetString("cboPaisResidenciaEmpresa.Items149"), resources.GetString("cboPaisResidenciaEmpresa.Items150"), resources.GetString("cboPaisResidenciaEmpresa.Items151"), resources.GetString("cboPaisResidenciaEmpresa.Items152"), resources.GetString("cboPaisResidenciaEmpresa.Items153"), resources.GetString("cboPaisResidenciaEmpresa.Items154"), resources.GetString("cboPaisResidenciaEmpresa.Items155"), resources.GetString("cboPaisResidenciaEmpresa.Items156"), resources.GetString("cboPaisResidenciaEmpresa.Items157"), resources.GetString("cboPaisResidenciaEmpresa.Items158"), resources.GetString("cboPaisResidenciaEmpresa.Items159"), resources.GetString("cboPaisResidenciaEmpresa.Items160"), resources.GetString("cboPaisResidenciaEmpresa.Items161"), resources.GetString("cboPaisResidenciaEmpresa.Items162"), resources.GetString("cboPaisResidenciaEmpresa.Items163"), resources.GetString("cboPaisResidenciaEmpresa.Items164"), resources.GetString("cboPaisResidenciaEmpresa.Items165"), resources.GetString("cboPaisResidenciaEmpresa.Items166"), resources.GetString("cboPaisResidenciaEmpresa.Items167"), resources.GetString("cboPaisResidenciaEmpresa.Items168"), resources.GetString("cboPaisResidenciaEmpresa.Items169"), resources.GetString("cboPaisResidenciaEmpresa.Items170"), resources.GetString("cboPaisResidenciaEmpresa.Items171"), resources.GetString("cboPaisResidenciaEmpresa.Items172"), resources.GetString("cboPaisResidenciaEmpresa.Items173"), resources.GetString("cboPaisResidenciaEmpresa.Items174"), resources.GetString("cboPaisResidenciaEmpresa.Items175"), resources.GetString("cboPaisResidenciaEmpresa.Items176"), resources.GetString("cboPaisResidenciaEmpresa.Items177"), resources.GetString("cboPaisResidenciaEmpresa.Items178"), resources.GetString("cboPaisResidenciaEmpresa.Items179"), resources.GetString("cboPaisResidenciaEmpresa.Items180"), resources.GetString("cboPaisResidenciaEmpresa.Items181"), resources.GetString("cboPaisResidenciaEmpresa.Items182"), resources.GetString("cboPaisResidenciaEmpresa.Items183"), resources.GetString("cboPaisResidenciaEmpresa.Items184"), resources.GetString("cboPaisResidenciaEmpresa.Items185"), resources.GetString("cboPaisResidenciaEmpresa.Items186"), resources.GetString("cboPaisResidenciaEmpresa.Items187"), resources.GetString("cboPaisResidenciaEmpresa.Items188"), resources.GetString("cboPaisResidenciaEmpresa.Items189"), resources.GetString("cboPaisResidenciaEmpresa.Items190"), resources.GetString("cboPaisResidenciaEmpresa.Items191"), resources.GetString("cboPaisResidenciaEmpresa.Items192"), resources.GetString("cboPaisResidenciaEmpresa.Items193"), resources.GetString("cboPaisResidenciaEmpresa.Items194"), resources.GetString("cboPaisResidenciaEmpresa.Items195"), resources.GetString("cboPaisResidenciaEmpresa.Items196")})
        Me.cboPaisResidenciaEmpresa.Name = "cboPaisResidenciaEmpresa"
        '
        'lblPaisResidencia
        '
        Me.lblPaisResidencia.AccessibleDescription = Nothing
        Me.lblPaisResidencia.AccessibleName = Nothing
        resources.ApplyResources(Me.lblPaisResidencia, "lblPaisResidencia")
        Me.lblPaisResidencia.Font = Nothing
        Me.lblPaisResidencia.Name = "lblPaisResidencia"
        '
        'cboPaisOrigenCapital
        '
        Me.cboPaisOrigenCapital.AccessibleDescription = Nothing
        Me.cboPaisOrigenCapital.AccessibleName = Nothing
        resources.ApplyResources(Me.cboPaisOrigenCapital, "cboPaisOrigenCapital")
        Me.cboPaisOrigenCapital.BackgroundImage = Nothing
        Me.cboPaisOrigenCapital.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboPaisOrigenCapital.Font = Nothing
        Me.cboPaisOrigenCapital.FormattingEnabled = True
        Me.cboPaisOrigenCapital.Name = "cboPaisOrigenCapital"
        '
        'txtRUT
        '
        Me.txtRUT.AccessibleDescription = Nothing
        Me.txtRUT.AccessibleName = Nothing
        resources.ApplyResources(Me.txtRUT, "txtRUT")
        Me.txtRUT.BackgroundImage = Nothing
        Me.txtRUT.Font = Nothing
        Me.txtRUT.Name = "txtRUT"
        '
        'lblPaisOrigen
        '
        Me.lblPaisOrigen.AccessibleDescription = Nothing
        Me.lblPaisOrigen.AccessibleName = Nothing
        resources.ApplyResources(Me.lblPaisOrigen, "lblPaisOrigen")
        Me.lblPaisOrigen.Font = Nothing
        Me.lblPaisOrigen.Name = "lblPaisOrigen"
        '
        'cboTipoSociedad
        '
        Me.cboTipoSociedad.AccessibleDescription = Nothing
        Me.cboTipoSociedad.AccessibleName = Nothing
        resources.ApplyResources(Me.cboTipoSociedad, "cboTipoSociedad")
        Me.cboTipoSociedad.BackgroundImage = Nothing
        Me.cboTipoSociedad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboTipoSociedad.Font = Nothing
        Me.cboTipoSociedad.FormattingEnabled = True
        Me.cboTipoSociedad.Items.AddRange(New Object() {resources.GetString("cboTipoSociedad.Items"), resources.GetString("cboTipoSociedad.Items1"), resources.GetString("cboTipoSociedad.Items2"), resources.GetString("cboTipoSociedad.Items3"), resources.GetString("cboTipoSociedad.Items4"), resources.GetString("cboTipoSociedad.Items5"), resources.GetString("cboTipoSociedad.Items6"), resources.GetString("cboTipoSociedad.Items7"), resources.GetString("cboTipoSociedad.Items8"), resources.GetString("cboTipoSociedad.Items9"), resources.GetString("cboTipoSociedad.Items10"), resources.GetString("cboTipoSociedad.Items11"), resources.GetString("cboTipoSociedad.Items12"), resources.GetString("cboTipoSociedad.Items13"), resources.GetString("cboTipoSociedad.Items14"), resources.GetString("cboTipoSociedad.Items15"), resources.GetString("cboTipoSociedad.Items16"), resources.GetString("cboTipoSociedad.Items17"), resources.GetString("cboTipoSociedad.Items18"), resources.GetString("cboTipoSociedad.Items19"), resources.GetString("cboTipoSociedad.Items20")})
        Me.cboTipoSociedad.Name = "cboTipoSociedad"
        '
        'lblRUT
        '
        Me.lblRUT.AccessibleDescription = Nothing
        Me.lblRUT.AccessibleName = Nothing
        resources.ApplyResources(Me.lblRUT, "lblRUT")
        Me.lblRUT.Font = Nothing
        Me.lblRUT.Name = "lblRUT"
        '
        'lblTipoSociedad
        '
        Me.lblTipoSociedad.AccessibleDescription = Nothing
        Me.lblTipoSociedad.AccessibleName = Nothing
        resources.ApplyResources(Me.lblTipoSociedad, "lblTipoSociedad")
        Me.lblTipoSociedad.Font = Nothing
        Me.lblTipoSociedad.Name = "lblTipoSociedad"
        '
        'lblRazonSocial
        '
        Me.lblRazonSocial.AccessibleDescription = Nothing
        Me.lblRazonSocial.AccessibleName = Nothing
        resources.ApplyResources(Me.lblRazonSocial, "lblRazonSocial")
        Me.lblRazonSocial.Font = Nothing
        Me.lblRazonSocial.Name = "lblRazonSocial"
        '
        'txtRazonSocial
        '
        Me.txtRazonSocial.AccessibleDescription = Nothing
        Me.txtRazonSocial.AccessibleName = Nothing
        resources.ApplyResources(Me.txtRazonSocial, "txtRazonSocial")
        Me.txtRazonSocial.BackgroundImage = Nothing
        Me.txtRazonSocial.Font = Nothing
        Me.txtRazonSocial.Name = "txtRazonSocial"
        '
        'frmAltaClienteEmpresa
        '
        Me.AccessibleDescription = Nothing
        Me.AccessibleName = Nothing
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Nothing
        Me.Controls.Add(Me.grpDatosEmpresa)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.btnEnviar)
        Me.Font = Nothing
        Me.MinimizeBox = False
        Me.Name = "frmAltaClienteEmpresa"
        Me.grpDatosEmpresa.ResumeLayout(False)
        Me.grpDatosEmpresa.PerformLayout()
        Me.grpContacto.ResumeLayout(False)
        Me.grpContacto.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents TextBox41 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox20 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox42 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox21 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox43 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox22 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox44 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox23 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox45 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox24 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox46 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox25 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox47 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox48 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox49 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox50 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox26 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox51 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox27 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox52 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox28 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox53 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox29 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox54 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox30 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox55 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox31 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox56 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox32 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox57 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox33 As System.Windows.Forms.ComboBox
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents TextBox58 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox34 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox59 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox60 As System.Windows.Forms.TextBox
    Friend WithEvents ComboBox35 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox61 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox62 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox63 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox64 As System.Windows.Forms.TextBox
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents RadioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents RadioButton4 As System.Windows.Forms.RadioButton
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents btnEnviar As System.Windows.Forms.Button
    Friend WithEvents btnLimpiar As System.Windows.Forms.Button
    Friend WithEvents grpDatosEmpresa As System.Windows.Forms.GroupBox
    Friend WithEvents grpContacto As System.Windows.Forms.GroupBox
    Friend WithEvents lblWeb As System.Windows.Forms.Label
    Friend WithEvents txtContactoSitioWeb As System.Windows.Forms.TextBox
    Friend WithEvents lblEmail As System.Windows.Forms.Label
    Friend WithEvents txtContactoEmail As System.Windows.Forms.TextBox
    Friend WithEvents lblTelefonos As System.Windows.Forms.Label
    Friend WithEvents txtContactoNumerosTelefono As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents lblCodPostal As System.Windows.Forms.Label
    Friend WithEvents txtDomicilioEmpresaCodPostal As System.Windows.Forms.TextBox
    Friend WithEvents lblAPTDomicilio As System.Windows.Forms.Label
    Friend WithEvents txtDomicilioEmpresaApartamento As System.Windows.Forms.TextBox
    Friend WithEvents lblBlockDomicilio As System.Windows.Forms.Label
    Friend WithEvents txtDomicilioEmpresaBlock As System.Windows.Forms.TextBox
    Friend WithEvents lblNroDomicilio As System.Windows.Forms.Label
    Friend WithEvents txtDomicilioEmpresaNumero As System.Windows.Forms.TextBox
    Friend WithEvents lblCalleDomicilio As System.Windows.Forms.Label
    Friend WithEvents txtDomicilioEmpresaCalle As System.Windows.Forms.TextBox
    Friend WithEvents lblDepartamento As System.Windows.Forms.Label
    Friend WithEvents txtDepartamentoEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents lblCiudad As System.Windows.Forms.Label
    Friend WithEvents txtCiudadEmpresa As System.Windows.Forms.TextBox
    Friend WithEvents cboPaisResidenciaEmpresa As System.Windows.Forms.ComboBox
    Friend WithEvents lblPaisResidencia As System.Windows.Forms.Label
    Friend WithEvents cboPaisOrigenCapital As System.Windows.Forms.ComboBox
    Friend WithEvents txtRUT As System.Windows.Forms.TextBox
    Friend WithEvents lblPaisOrigen As System.Windows.Forms.Label
    Friend WithEvents cboTipoSociedad As System.Windows.Forms.ComboBox
    Friend WithEvents lblRUT As System.Windows.Forms.Label
    Friend WithEvents lblTipoSociedad As System.Windows.Forms.Label
    Friend WithEvents lblRazonSocial As System.Windows.Forms.Label
    Friend WithEvents txtRazonSocial As System.Windows.Forms.TextBox
End Class
