﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmAperturaCaja
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmAperturaCaja))
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtSucursal = New System.Windows.Forms.TextBox
        Me.txtCaja = New System.Windows.Forms.TextBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.txtCajero = New System.Windows.Forms.TextBox
        Me.Label3 = New System.Windows.Forms.Label
        Me.txtEmailCajero = New System.Windows.Forms.TextBox
        Me.txtSaldoUYU = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.txtFecha = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtHora = New System.Windows.Forms.TextBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.txtSaldoUSD = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.btnConfirmar = New System.Windows.Forms.Button
        Me.btnCancelar = New System.Windows.Forms.Button
        Me.lblSucursal = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AccessibleDescription = Nothing
        Me.Label1.AccessibleName = Nothing
        resources.ApplyResources(Me.Label1, "Label1")
        Me.Label1.Font = Nothing
        Me.Label1.Name = "Label1"
        '
        'txtSucursal
        '
        Me.txtSucursal.AccessibleDescription = Nothing
        Me.txtSucursal.AccessibleName = Nothing
        resources.ApplyResources(Me.txtSucursal, "txtSucursal")
        Me.txtSucursal.BackgroundImage = Nothing
        Me.txtSucursal.Font = Nothing
        Me.txtSucursal.Name = "txtSucursal"
        '
        'txtCaja
        '
        Me.txtCaja.AccessibleDescription = Nothing
        Me.txtCaja.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCaja, "txtCaja")
        Me.txtCaja.BackgroundImage = Nothing
        Me.txtCaja.Font = Nothing
        Me.txtCaja.Name = "txtCaja"
        '
        'Label2
        '
        Me.Label2.AccessibleDescription = Nothing
        Me.Label2.AccessibleName = Nothing
        resources.ApplyResources(Me.Label2, "Label2")
        Me.Label2.Font = Nothing
        Me.Label2.Name = "Label2"
        '
        'txtCajero
        '
        Me.txtCajero.AccessibleDescription = Nothing
        Me.txtCajero.AccessibleName = Nothing
        resources.ApplyResources(Me.txtCajero, "txtCajero")
        Me.txtCajero.BackgroundImage = Nothing
        Me.txtCajero.Font = Nothing
        Me.txtCajero.Name = "txtCajero"
        '
        'Label3
        '
        Me.Label3.AccessibleDescription = Nothing
        Me.Label3.AccessibleName = Nothing
        resources.ApplyResources(Me.Label3, "Label3")
        Me.Label3.Font = Nothing
        Me.Label3.Name = "Label3"
        '
        'txtEmailCajero
        '
        Me.txtEmailCajero.AccessibleDescription = Nothing
        Me.txtEmailCajero.AccessibleName = Nothing
        resources.ApplyResources(Me.txtEmailCajero, "txtEmailCajero")
        Me.txtEmailCajero.BackgroundImage = Nothing
        Me.txtEmailCajero.Font = Nothing
        Me.txtEmailCajero.Name = "txtEmailCajero"
        '
        'txtSaldoUYU
        '
        Me.txtSaldoUYU.AccessibleDescription = Nothing
        Me.txtSaldoUYU.AccessibleName = Nothing
        resources.ApplyResources(Me.txtSaldoUYU, "txtSaldoUYU")
        Me.txtSaldoUYU.BackgroundImage = Nothing
        Me.txtSaldoUYU.Name = "txtSaldoUYU"
        '
        'Label4
        '
        Me.Label4.AccessibleDescription = Nothing
        Me.Label4.AccessibleName = Nothing
        resources.ApplyResources(Me.Label4, "Label4")
        Me.Label4.Font = Nothing
        Me.Label4.Name = "Label4"
        '
        'txtFecha
        '
        Me.txtFecha.AccessibleDescription = Nothing
        Me.txtFecha.AccessibleName = Nothing
        resources.ApplyResources(Me.txtFecha, "txtFecha")
        Me.txtFecha.BackgroundImage = Nothing
        Me.txtFecha.Font = Nothing
        Me.txtFecha.Name = "txtFecha"
        '
        'Label6
        '
        Me.Label6.AccessibleDescription = Nothing
        Me.Label6.AccessibleName = Nothing
        resources.ApplyResources(Me.Label6, "Label6")
        Me.Label6.Font = Nothing
        Me.Label6.Name = "Label6"
        '
        'txtHora
        '
        Me.txtHora.AccessibleDescription = Nothing
        Me.txtHora.AccessibleName = Nothing
        resources.ApplyResources(Me.txtHora, "txtHora")
        Me.txtHora.BackgroundImage = Nothing
        Me.txtHora.Font = Nothing
        Me.txtHora.Name = "txtHora"
        '
        'Label7
        '
        Me.Label7.AccessibleDescription = Nothing
        Me.Label7.AccessibleName = Nothing
        resources.ApplyResources(Me.Label7, "Label7")
        Me.Label7.Font = Nothing
        Me.Label7.Name = "Label7"
        '
        'txtSaldoUSD
        '
        Me.txtSaldoUSD.AccessibleDescription = Nothing
        Me.txtSaldoUSD.AccessibleName = Nothing
        resources.ApplyResources(Me.txtSaldoUSD, "txtSaldoUSD")
        Me.txtSaldoUSD.BackgroundImage = Nothing
        Me.txtSaldoUSD.Name = "txtSaldoUSD"
        '
        'Label5
        '
        Me.Label5.AccessibleDescription = Nothing
        Me.Label5.AccessibleName = Nothing
        resources.ApplyResources(Me.Label5, "Label5")
        Me.Label5.Font = Nothing
        Me.Label5.Name = "Label5"
        '
        'btnConfirmar
        '
        Me.btnConfirmar.AccessibleDescription = Nothing
        Me.btnConfirmar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnConfirmar, "btnConfirmar")
        Me.btnConfirmar.BackgroundImage = Nothing
        Me.btnConfirmar.Name = "btnConfirmar"
        Me.btnConfirmar.UseVisualStyleBackColor = True
        '
        'btnCancelar
        '
        Me.btnCancelar.AccessibleDescription = Nothing
        Me.btnCancelar.AccessibleName = Nothing
        resources.ApplyResources(Me.btnCancelar, "btnCancelar")
        Me.btnCancelar.BackgroundImage = Nothing
        Me.btnCancelar.Name = "btnCancelar"
        Me.btnCancelar.UseVisualStyleBackColor = True
        '
        'lblSucursal
        '
        Me.lblSucursal.AccessibleDescription = Nothing
        Me.lblSucursal.AccessibleName = Nothing
        resources.ApplyResources(Me.lblSucursal, "lblSucursal")
        Me.lblSucursal.Font = Nothing
        Me.lblSucursal.Name = "lblSucursal"
        '
        'frmAperturaCaja
        '
        Me.AccessibleDescription = Nothing
        Me.AccessibleName = Nothing
        resources.ApplyResources(Me, "$this")
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Nothing
        Me.Controls.Add(Me.lblSucursal)
        Me.Controls.Add(Me.btnCancelar)
        Me.Controls.Add(Me.btnConfirmar)
        Me.Controls.Add(Me.txtSaldoUSD)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtHora)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtFecha)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtSaldoUYU)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtEmailCajero)
        Me.Controls.Add(Me.txtCajero)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.txtCaja)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtSucursal)
        Me.Controls.Add(Me.Label1)
        Me.Font = Nothing
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.Name = "frmAperturaCaja"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtSucursal As System.Windows.Forms.TextBox
    Friend WithEvents txtCaja As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtCajero As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtEmailCajero As System.Windows.Forms.TextBox
    Friend WithEvents txtSaldoUYU As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtFecha As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtHora As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtSaldoUSD As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnConfirmar As System.Windows.Forms.Button
    Friend WithEvents btnCancelar As System.Windows.Forms.Button
    Friend WithEvents lblSucursal As System.Windows.Forms.Label
End Class
