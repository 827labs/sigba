﻿Public Class Cotizaciones
    Public Shared cotUSD As String
    Public Shared cotEUR As String
End Class
